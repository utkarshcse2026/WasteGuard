class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Desktop - One images
  static String imgGroup4 = '$imagePath/img_group_4.svg';

  static String imgMobileBankingApp = '$imagePath/img_mobile_banking_app.png';

  static String imgSlideUp = '$imagePath/img_slide_up.png';

  // Desktop - Two images
  static String imgSmilingManWith = '$imagePath/img_smiling_man_with.png';

  static String imgSecure = '$imagePath/img_secure.png';

  // Desktop - Four images
  static String imgMaleUser = '$imagePath/img_male_user.png';

  static String imgUnsplash = '$imagePath/img_unsplash.png';

  // Desktop - Seven images
  static String imgInProgress = '$imagePath/img_in_progress.png';

  // Desktop - Eight images
  static String imgComplaint = '$imagePath/img_complaint.png';

  static String imgHappyThankfulMan = '$imagePath/img_happy_thankful_man.png';

  static String imgMap = '$imagePath/img_map.png';

  static String imgGreenTruck = '$imagePath/img_green_truck.png';

  static String imgUserFeedback = '$imagePath/img_user_feedback.png';

  // Desktop - Nine images
  static String imgRobotNavigator = '$imagePath/img_robot_navigator.png';

  static String imgEllipse9 = '$imagePath/img_ellipse_9.png';

  static String imgGarbageBag = '$imagePath/img_garbage_bag.png';

  static String imgLandfill = '$imagePath/img_landfill.png';

  static String imgGarbageTruck = '$imagePath/img_garbage_truck.png';

  // Desktop - Fourteen images
  static String imgGroup100 = '$imagePath/img_group_100.png';

  // Desktop - Fifteen images
  static String imgChristmasStar = '$imagePath/img_christmas_star.png';

  // Common images
  static String imgWhatIsAWaste = '$imagePath/img_what_is_a_waste.png';

  static String imgBack = '$imagePath/img_back.png';

  static String imgCurvedGreenLeaf = '$imagePath/img_curved_green_leaf.png';

  static String imgGreenInfographics = '$imagePath/img_green_infographics.png';

  static String imgCheckmark = '$imagePath/img_checkmark.png';

  static String imgGreenInfographics459x594 =
      '$imagePath/img_green_infographics_459x594.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
