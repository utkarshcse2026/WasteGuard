import 'package:flutter/material.dart';
import '../presentation/desktop_one_screen/desktop_one_screen.dart';
import '../presentation/desktop_two_screen/desktop_two_screen.dart';
import '../presentation/desktop_three_screen/desktop_three_screen.dart';
import '../presentation/desktop_four_screen/desktop_four_screen.dart';
import '../presentation/desktop_five_screen/desktop_five_screen.dart';
import '../presentation/desktop_six_screen/desktop_six_screen.dart';
import '../presentation/desktop_seven_screen/desktop_seven_screen.dart';
import '../presentation/desktop_eight_screen/desktop_eight_screen.dart';
import '../presentation/desktop_nine_screen/desktop_nine_screen.dart';
import '../presentation/desktop_ten_screen/desktop_ten_screen.dart';
import '../presentation/desktop_eleven_screen/desktop_eleven_screen.dart';
import '../presentation/desktop_twelve_screen/desktop_twelve_screen.dart';
import '../presentation/desktop_thirteen_screen/desktop_thirteen_screen.dart';
import '../presentation/desktop_fourteen_screen/desktop_fourteen_screen.dart';
import '../presentation/desktop_fifteen_screen/desktop_fifteen_screen.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String desktopOneScreen = '/desktop_one_screen';

  static const String desktopTwoScreen = '/desktop_two_screen';

  static const String desktopThreeScreen = '/desktop_three_screen';

  static const String desktopFourScreen = '/desktop_four_screen';

  static const String desktopFiveScreen = '/desktop_five_screen';

  static const String desktopSixScreen = '/desktop_six_screen';

  static const String desktopSevenScreen = '/desktop_seven_screen';

  static const String desktopEightScreen = '/desktop_eight_screen';

  static const String desktopNineScreen = '/desktop_nine_screen';

  static const String desktopTenScreen = '/desktop_ten_screen';

  static const String desktopElevenScreen = '/desktop_eleven_screen';

  static const String desktopTwelveScreen = '/desktop_twelve_screen';

  static const String desktopThirteenScreen = '/desktop_thirteen_screen';

  static const String desktopFourteenScreen = '/desktop_fourteen_screen';

  static const String desktopFifteenScreen = '/desktop_fifteen_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        desktopOneScreen: DesktopOneScreen.builder,
        desktopTwoScreen: DesktopTwoScreen.builder,
        desktopThreeScreen: DesktopThreeScreen.builder,
        desktopFourScreen: DesktopFourScreen.builder,
        desktopFiveScreen: DesktopFiveScreen.builder,
        desktopSixScreen: DesktopSixScreen.builder,
        desktopSevenScreen: DesktopSevenScreen.builder,
        desktopEightScreen: DesktopEightScreen.builder,
        desktopNineScreen: DesktopNineScreen.builder,
        desktopTenScreen: DesktopTenScreen.builder,
        desktopElevenScreen: DesktopElevenScreen.builder,
        desktopTwelveScreen: DesktopTwelveScreen.builder,
        desktopThirteenScreen: DesktopThirteenScreen.builder,
        desktopFourteenScreen: DesktopFourteenScreen.builder,
        desktopFifteenScreen: DesktopFifteenScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: DesktopOneScreen.builder
      };
}
