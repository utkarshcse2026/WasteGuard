import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Akaya text style
  static get akayaKanadakaOnPrimaryContainer => TextStyle(
        color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
        fontSize: 80.fSize,
        fontWeight: FontWeight.w400,
      ).akayaKanadaka;
  static get akayaKanadakaWhiteA700 => TextStyle(
        color: appTheme.whiteA700,
        fontSize: 80.fSize,
        fontWeight: FontWeight.w400,
      ).akayaKanadaka;
  // Display text style
  static get displayLargeOnPrimaryContainer =>
      theme.textTheme.displayLarge!.copyWith(
        color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
      );
  static get displayMedium40 => theme.textTheme.displayMedium!.copyWith(
        fontSize: 40.fSize,
      );
  static get displayMedium45 => theme.textTheme.displayMedium!.copyWith(
        fontSize: 45.fSize,
      );
  static get displayMedium48 => theme.textTheme.displayMedium!.copyWith(
        fontSize: 48.fSize,
      );
  static get displayMediumLime900 => theme.textTheme.displayMedium!.copyWith(
        color: appTheme.lime900,
        fontSize: 48.fSize,
      );
  static get displayMediumOnPrimary => theme.textTheme.displayMedium!.copyWith(
        color: theme.colorScheme.onPrimary,
        fontSize: 48.fSize,
      );
  static get displayMediumOnPrimary40 =>
      theme.textTheme.displayMedium!.copyWith(
        color: theme.colorScheme.onPrimary,
        fontSize: 40.fSize,
      );
  static get displayMediumOnPrimaryContainer =>
      theme.textTheme.displayMedium!.copyWith(
        color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
        fontSize: 40.fSize,
      );
  static get displayMediumOnPrimaryContainer48 =>
      theme.textTheme.displayMedium!.copyWith(
        color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
        fontSize: 48.fSize,
      );
  static get displayMediumOnPrimaryContainer_1 =>
      theme.textTheme.displayMedium!.copyWith(
        color: theme.colorScheme.onPrimaryContainer.withOpacity(1),
      );
  static get displayMediumRedA700 => theme.textTheme.displayMedium!.copyWith(
        color: appTheme.redA700,
        fontSize: 48.fSize,
      );
  static get displaySmall37 => theme.textTheme.displaySmall!.copyWith(
        fontSize: 37.fSize,
      );
  static get displaySmallGray300 => theme.textTheme.displaySmall!.copyWith(
        color: appTheme.gray300,
        fontSize: 37.fSize,
      );
  static get displaySmallGray40001 => theme.textTheme.displaySmall!.copyWith(
        color: appTheme.gray40001,
        fontSize: 35.fSize,
      );
  static get displaySmallWhiteA700 => theme.textTheme.displaySmall!.copyWith(
        color: appTheme.whiteA700,
      );
  static get displaySmallff06197b => theme.textTheme.displaySmall!.copyWith(
        color: Color(0XFF06197B),
        fontSize: 35.fSize,
      );
  static get displaySmallffc8c4c4 => theme.textTheme.displaySmall!.copyWith(
        color: Color(0XFFC8C4C4),
        fontSize: 35.fSize,
      );
  // Headline text style
  static get headlineLarge30 => theme.textTheme.headlineLarge!.copyWith(
        fontSize: 30.fSize,
      );
  static get headlineLargeGray400 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.gray400,
        fontSize: 30.fSize,
      );
  static get headlineLargeGray700 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.gray700,
        fontSize: 30.fSize,
      );
  static get headlineLargeRedA70001 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.redA70001,
      );
  static get headlineLargeWhiteA700 => theme.textTheme.headlineLarge!.copyWith(
        color: appTheme.whiteA700,
        fontSize: 30.fSize,
      );
}

extension on TextStyle {
  TextStyle get akayaKanadaka {
    return copyWith(
      fontFamily: 'Akaya Kanadaka',
    );
  }
}
