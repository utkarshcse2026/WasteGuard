import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A class that offers pre-defined button styles for customizing button appearance.
class CustomButtonStyles {
  // Filled button style
  static ButtonStyle get fillCyan => ElevatedButton.styleFrom(
        backgroundColor: appTheme.cyan800,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25.h),
        ),
      );

  // Outline button style
  static ButtonStyle get outlineGreen => OutlinedButton.styleFrom(
        backgroundColor: appTheme.green800,
        side: BorderSide(
          color: appTheme.green800,
          width: 1,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(36.h),
        ),
      );
  static ButtonStyle get outlinePrimary => ElevatedButton.styleFrom(
        backgroundColor: appTheme.cyan800,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(41.h),
        ),
        shadowColor: theme.colorScheme.primary,
        elevation: 7,
      );
  static ButtonStyle get outlinePrimaryTL10 => ElevatedButton.styleFrom(
        backgroundColor: appTheme.whiteA700,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.h),
        ),
        shadowColor: theme.colorScheme.primary,
        elevation: 7,
      );
  static ButtonStyle get outlinePrimaryTL20 => ElevatedButton.styleFrom(
        backgroundColor: appTheme.blueGray100,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.h),
        ),
        shadowColor: theme.colorScheme.primary,
        elevation: 10,
      );
  static ButtonStyle get outlinePrimaryTL41 => ElevatedButton.styleFrom(
        backgroundColor: appTheme.lime900,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(41.h),
        ),
        shadowColor: theme.colorScheme.primary,
        elevation: 7,
      );
  static ButtonStyle get outlinePrimaryTL45 => ElevatedButton.styleFrom(
        backgroundColor: appTheme.deepOrange900,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(45.h),
        ),
        shadowColor: theme.colorScheme.primary,
        elevation: 10,
      );
  // text button style
  static ButtonStyle get none => ButtonStyle(
        backgroundColor: MaterialStateProperty.all<Color>(Colors.transparent),
        elevation: MaterialStateProperty.all<double>(0),
      );
}
