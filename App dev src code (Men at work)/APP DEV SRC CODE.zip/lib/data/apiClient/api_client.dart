import 'package:waste_guard/core/app_export.dart';

class ApiClient {}
