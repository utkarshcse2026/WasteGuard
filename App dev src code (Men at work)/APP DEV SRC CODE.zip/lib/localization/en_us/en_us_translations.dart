final Map<String, String> enUs = {
  // Desktop - One Screen
  "lbl_get_started": "Get started ", "lbl_waste_guard": "WASTE GUARD",

  // Desktop - Two Screen
  "lbl_login": "Login",
  "lbl_sign_up": "Sign up",
  "lbl_welcome_back": "WELCOME BACK",
  "msg_don_t_have_account": "Don’t have account? Sign up",
  "msg_don_t_have_account2": "Don’t have account? ",
  "msg_forgot_password": "Forgot password?",
  "msg_login_to_your_account": "Login to your account",

  // Desktop - Three Screen
  "lbl_e_mail_i_d": "E MAIL I’D", "lbl_proceed": "Proceed",
  "lbl_register": "REGISTER", "msg_create_your_new": "Create your new account",

  // Desktop - Four Screen
  "lbl_about_youself": "About Youself",
  "lbl_address": "Address",
  "lbl_create_account": "Create account",
  "lbl_full": "Full ",
  "lbl_full_name": "Full Name",
  "lbl_phone_no": "Phone no.",

  // Desktop - Five Screen
  "lbl_123_80": "123*****80", "lbl_verify": "Verify",
  "msg_we_have_send_you": "We have send you a verification code on",

  // Desktop - Six Screen
  "lbl_invalid": " Invalid !!", "lbl_re_send_code": "Re-send code",
  "msg_please_enter_the": "Please enter the code correctly",

  // Desktop - Seven Screen
  "lbl_verified": "Verified",
  "lbl_waste_guard2": "“WASTE GUARD”",
  "lbl_your_account_on": "your account on ",
  "msg_successfully_created": "Successfully created ",

  // Desktop - Eight Screen
  "lbl_complaints": "Complaints",
  "lbl_features": "FEATURES",
  "lbl_feedback": "Feedback",
  "lbl_proximity": "proximity",
  "lbl_requests": "Requests ",
  "lbl_vehicle": "Vehicle ",

  // Desktop - Nine Screen
  "lbl_category": "Category",

  // Desktop - Eleven Screen
  "lbl_current_address": " Current Address ",

  // Desktop - Twelve Screen
  "lbl_requests2": "Requests",
  "msg_describe_your_request": "Describe your request ",

  // Desktop - Thirteen Screen
  "lbl_correct_address": "Correct address",
  "lbl_enter_your_city": "Enter your city",
  "lbl_find_distance": "Find distance",
  "msg_enter_your_area": "Enter your area pincode",
  "msg_enter_your_country": "Enter your country",
  "msg_enter_your_state": "Enter your state",
  "msg_vehicle_proximity": "Vehicle proximity  ",

  // Desktop - Fifteen Screen
  "lbl_feedback2": "feedback",
  "lbl_think": "think.",
  "msg_evaluate_and_tell": "evaluate and tell us what you ",
  "msg_please_take_a_moment": "Please take a moment to ",
  "msg_to_improve_your": "to improve your experience.",
  "msg_we_appreciate_your": "We appreciate your",
  "msg_we_are_always_looking": "we are always looking for ways ",
  "msg_what_can_we_do_to": "what can we do to improve your",

  // Common String
  "lbl_area_pincode": "Area pincode",
  "lbl_complaints2": "COMPLAINTS",
  "lbl_dumping_side": "Dumping side",
  "lbl_in_detail": "in detail.",
  "lbl_password": "PASSWORD",
  "lbl_remember_me": "Remember me?",
  "lbl_service": "Service",
  "lbl_submit": "Submit",
  "lbl_user_name": "USER NAME ",
  "msg_address_area_pincode": "Address (Area pincode)",
  "msg_describe_your_complaint": "Describe your complaint ",
  "msg_enter_the_code_here": "ENTER THE CODE HERE",
  "msg_geotagging_image": "Geotagging image ",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",

  // Validation Error String
  "err_msg_please_enter_valid_text": "Please enter valid text",
  "err_msg_please_enter_valid_password": "Please enter valid password",
  "err_msg_please_enter_valid_number": "Please enter valid number",
};
