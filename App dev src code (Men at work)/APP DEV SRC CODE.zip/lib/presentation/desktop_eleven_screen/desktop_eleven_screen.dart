import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/core/utils/validation_functions.dart';
import 'package:waste_guard/widgets/custom_elevated_button.dart';
import 'package:waste_guard/widgets/custom_text_form_field.dart';
import 'bloc/desktop_eleven_bloc.dart';
import 'models/desktop_eleven_model.dart';

class DesktopElevenScreen extends StatelessWidget {
  DesktopElevenScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopElevenBloc>(
      create: (context) => DesktopElevenBloc(DesktopElevenState(
        desktopElevenModelObj: DesktopElevenModel(),
      ))
        ..add(DesktopElevenInitialEvent()),
      child: DesktopElevenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: SizedBox(
            width: 594.h,
            child: Column(
              children: [
                SizedBox(height: 53.v),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildBackRow(context),
                        SizedBox(height: 19.v),
                        SizedBox(
                          height: 836.v,
                          width: 594.h,
                          child: Stack(
                            alignment: Alignment.topCenter,
                            children: [
                              CustomImageView(
                                imagePath:
                                    ImageConstant.imgGreenInfographics459x594,
                                height: 459.v,
                                width: 594.h,
                                alignment: Alignment.bottomCenter,
                              ),
                              Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                  margin:
                                      EdgeInsets.symmetric(horizontal: 57.h),
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 32.h,
                                    vertical: 53.v,
                                  ),
                                  decoration: AppDecoration.fillGreen.copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder45,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SizedBox(height: 12.v),
                                      Container(
                                        width: 414.h,
                                        margin: EdgeInsets.only(left: 1.h),
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 20.h,
                                          vertical: 39.v,
                                        ),
                                        decoration: AppDecoration
                                            .outlinePrimary2
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder20,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              "msg_describe_your_complaint".tr,
                                              style:
                                                  theme.textTheme.displaySmall,
                                            ),
                                            SizedBox(height: 50.v),
                                            Text(
                                              "lbl_in_detail".tr,
                                              style:
                                                  theme.textTheme.displaySmall,
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(height: 61.v),
                                      Container(
                                        width: 414.h,
                                        margin: EdgeInsets.only(left: 1.h),
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 19.h,
                                          vertical: 10.v,
                                        ),
                                        decoration: AppDecoration
                                            .outlinePrimary2
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder20,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            SizedBox(height: 7.v),
                                            Text(
                                              "lbl_current_address".tr,
                                              style:
                                                  theme.textTheme.displaySmall,
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(height: 27.v),
                                      BlocSelector<
                                          DesktopElevenBloc,
                                          DesktopElevenState,
                                          TextEditingController?>(
                                        selector: (state) =>
                                            state.pincodeController,
                                        builder: (context, pincodeController) {
                                          return CustomTextFormField(
                                            controller: pincodeController,
                                            hintText: "lbl_area_pincode".tr,
                                            textInputAction:
                                                TextInputAction.done,
                                            textInputType:
                                                TextInputType.visiblePassword,
                                            validator: (value) {
                                              if (value == null ||
                                                  (!isValidPassword(value,
                                                      isRequired: true))) {
                                                return "err_msg_please_enter_valid_password"
                                                    .tr;
                                              }
                                              return null;
                                            },
                                            obscureText: true,
                                          );
                                        },
                                      ),
                                      SizedBox(height: 42.v),
                                      CustomElevatedButton(
                                        text: "lbl_submit".tr,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildBackRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 65.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgBack,
            height: 64.adaptSize,
            width: 64.adaptSize,
            margin: EdgeInsets.only(bottom: 94.v),
          ),
          Container(
            height: 135.v,
            width: 441.h,
            margin: EdgeInsets.only(
              left: 23.h,
              top: 23.v,
            ),
            child: Stack(
              alignment: Alignment.bottomRight,
              children: [
                Align(
                  alignment: Alignment.topCenter,
                  child: Text(
                    "lbl_complaints2".tr,
                    style: CustomTextStyles.akayaKanadakaOnPrimaryContainer,
                  ),
                ),
                Align(
                  alignment: Alignment.bottomRight,
                  child: Padding(
                    padding: EdgeInsets.only(right: 25.h),
                    child: Text(
                      "lbl_service".tr,
                      style: CustomTextStyles.displayMediumOnPrimary,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
