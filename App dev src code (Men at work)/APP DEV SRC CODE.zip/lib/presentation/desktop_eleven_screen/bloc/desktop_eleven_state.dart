// ignore_for_file: must_be_immutable

part of 'desktop_eleven_bloc.dart';

/// Represents the state of DesktopEleven in the application.
class DesktopElevenState extends Equatable {
  DesktopElevenState({
    this.pincodeController,
    this.desktopElevenModelObj,
  });

  TextEditingController? pincodeController;

  DesktopElevenModel? desktopElevenModelObj;

  @override
  List<Object?> get props => [
        pincodeController,
        desktopElevenModelObj,
      ];

  DesktopElevenState copyWith({
    TextEditingController? pincodeController,
    DesktopElevenModel? desktopElevenModelObj,
  }) {
    return DesktopElevenState(
      pincodeController: pincodeController ?? this.pincodeController,
      desktopElevenModelObj:
          desktopElevenModelObj ?? this.desktopElevenModelObj,
    );
  }
}
