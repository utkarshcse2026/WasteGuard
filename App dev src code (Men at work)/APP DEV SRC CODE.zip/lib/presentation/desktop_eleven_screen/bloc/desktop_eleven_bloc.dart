import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_eleven_screen/models/desktop_eleven_model.dart';
part 'desktop_eleven_event.dart';
part 'desktop_eleven_state.dart';

/// A bloc that manages the state of a DesktopEleven according to the event that is dispatched to it.
class DesktopElevenBloc extends Bloc<DesktopElevenEvent, DesktopElevenState> {
  DesktopElevenBloc(DesktopElevenState initialState) : super(initialState) {
    on<DesktopElevenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopElevenInitialEvent event,
    Emitter<DesktopElevenState> emit,
  ) async {
    emit(state.copyWith(
      pincodeController: TextEditingController(),
    ));
  }
}
