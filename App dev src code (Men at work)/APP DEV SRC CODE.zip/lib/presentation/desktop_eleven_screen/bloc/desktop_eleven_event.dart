// ignore_for_file: must_be_immutable

part of 'desktop_eleven_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///DesktopEleven widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class DesktopElevenEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the DesktopEleven widget is first created.
class DesktopElevenInitialEvent extends DesktopElevenEvent {
  @override
  List<Object?> get props => [];
}
