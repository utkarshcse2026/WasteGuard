// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [desktop_seven_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class DesktopSevenModel extends Equatable {
  DesktopSevenModel() {}

  DesktopSevenModel copyWith() {
    return DesktopSevenModel();
  }

  @override
  List<Object?> get props => [];
}
