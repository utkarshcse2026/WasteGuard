import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/widgets/custom_elevated_button.dart';
import 'bloc/desktop_seven_bloc.dart';
import 'models/desktop_seven_model.dart';

class DesktopSevenScreen extends StatelessWidget {
  const DesktopSevenScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopSevenBloc>(
      create: (context) => DesktopSevenBloc(DesktopSevenState(
        desktopSevenModelObj: DesktopSevenModel(),
      ))
        ..add(DesktopSevenInitialEvent()),
      child: DesktopSevenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DesktopSevenBloc, DesktopSevenState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: SizedBox(
              width: 594.h,
              child: Column(
                children: [
                  SizedBox(height: 37.v),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgBack,
                            height: 64.adaptSize,
                            width: 64.adaptSize,
                            margin: EdgeInsets.only(left: 21.h),
                          ),
                          SizedBox(height: 96.v),
                          SizedBox(
                            height: 870.v,
                            width: 594.h,
                            child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                CustomImageView(
                                  imagePath:
                                      ImageConstant.imgGreenInfographics459x594,
                                  height: 459.v,
                                  width: 594.h,
                                  alignment: Alignment.bottomCenter,
                                ),
                                _buildUserProfileSection(context),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildUserProfileSection(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 41.h),
        padding: EdgeInsets.symmetric(
          horizontal: 43.h,
          vertical: 41.v,
        ),
        decoration: AppDecoration.fillGreen.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder50,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "msg_successfully_created".tr,
              style: CustomTextStyles.displayMediumOnPrimaryContainer_1,
            ),
            Container(
              height: 100.v,
              width: 351.h,
              margin: EdgeInsets.only(left: 18.h),
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: Padding(
                      padding: EdgeInsets.only(right: 1.h),
                      child: Text(
                        "lbl_your_account_on".tr,
                        style:
                            CustomTextStyles.displayMediumOnPrimaryContainer_1,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Text(
                      "lbl_waste_guard2".tr,
                      style: CustomTextStyles.displayMediumOnPrimaryContainer_1,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 17.v),
            CustomImageView(
              imagePath: ImageConstant.imgInProgress,
              height: 155.v,
              width: 271.h,
              margin: EdgeInsets.only(left: 64.h),
            ),
            SizedBox(height: 13.v),
            CustomElevatedButton(
              height: 82.v,
              text: "lbl_verified".tr,
              margin: EdgeInsets.only(right: 7.h),
              buttonStyle: CustomButtonStyles.outlinePrimaryTL41,
            ),
            SizedBox(height: 12.v),
          ],
        ),
      ),
    );
  }
}
