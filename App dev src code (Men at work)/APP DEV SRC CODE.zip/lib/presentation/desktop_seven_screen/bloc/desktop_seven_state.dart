// ignore_for_file: must_be_immutable

part of 'desktop_seven_bloc.dart';

/// Represents the state of DesktopSeven in the application.
class DesktopSevenState extends Equatable {
  DesktopSevenState({this.desktopSevenModelObj});

  DesktopSevenModel? desktopSevenModelObj;

  @override
  List<Object?> get props => [
        desktopSevenModelObj,
      ];

  DesktopSevenState copyWith({DesktopSevenModel? desktopSevenModelObj}) {
    return DesktopSevenState(
      desktopSevenModelObj: desktopSevenModelObj ?? this.desktopSevenModelObj,
    );
  }
}
