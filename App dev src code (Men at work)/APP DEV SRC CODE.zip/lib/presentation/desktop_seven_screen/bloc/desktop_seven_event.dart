// ignore_for_file: must_be_immutable

part of 'desktop_seven_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///DesktopSeven widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class DesktopSevenEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the DesktopSeven widget is first created.
class DesktopSevenInitialEvent extends DesktopSevenEvent {
  @override
  List<Object?> get props => [];
}
