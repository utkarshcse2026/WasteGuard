import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_eight_screen/models/desktop_eight_model.dart';
part 'desktop_eight_event.dart';
part 'desktop_eight_state.dart';

/// A bloc that manages the state of a DesktopEight according to the event that is dispatched to it.
class DesktopEightBloc extends Bloc<DesktopEightEvent, DesktopEightState> {
  DesktopEightBloc(DesktopEightState initialState) : super(initialState) {
    on<DesktopEightInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopEightInitialEvent event,
    Emitter<DesktopEightState> emit,
  ) async {}
}
