// ignore_for_file: must_be_immutable

part of 'desktop_eight_bloc.dart';

/// Represents the state of DesktopEight in the application.
class DesktopEightState extends Equatable {
  DesktopEightState({this.desktopEightModelObj});

  DesktopEightModel? desktopEightModelObj;

  @override
  List<Object?> get props => [
        desktopEightModelObj,
      ];

  DesktopEightState copyWith({DesktopEightModel? desktopEightModelObj}) {
    return DesktopEightState(
      desktopEightModelObj: desktopEightModelObj ?? this.desktopEightModelObj,
    );
  }
}
