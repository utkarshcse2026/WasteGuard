import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'bloc/desktop_eight_bloc.dart';
import 'models/desktop_eight_model.dart';

class DesktopEightScreen extends StatelessWidget {
  const DesktopEightScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopEightBloc>(
      create: (context) => DesktopEightBloc(DesktopEightState(
        desktopEightModelObj: DesktopEightModel(),
      ))
        ..add(DesktopEightInitialEvent()),
      child: DesktopEightScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DesktopEightBloc, DesktopEightState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: SizedBox(
              width: 594.h,
              child: Column(
                children: [
                  SizedBox(height: 30.v),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgBack,
                            height: 40.v,
                            width: 64.h,
                            margin: EdgeInsets.only(left: 5.h),
                          ),
                          SizedBox(height: 1.v),
                          Align(
                            alignment: Alignment.center,
                            child: Padding(
                              padding: EdgeInsets.only(right: 1.h),
                              child: Text(
                                "lbl_features".tr,
                                style: CustomTextStyles
                                    .akayaKanadakaOnPrimaryContainer,
                              ),
                            ),
                          ),
                          SizedBox(height: 25.v),
                          _buildThirtySixSection(context),
                          _buildSeventyFourSection(context),
                          SizedBox(height: 12.v),
                          SizedBox(
                            height: 544.v,
                            width: 594.h,
                            child: Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                _buildFiftyEightSection(context),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Container(
                                    height: 173.v,
                                    width: 214.h,
                                    margin: EdgeInsets.only(
                                      left: 8.h,
                                      top: 20.v,
                                    ),
                                    child: Stack(
                                      alignment: Alignment.centerRight,
                                      children: [
                                        Opacity(
                                          opacity: 0.5,
                                          child: Align(
                                            alignment: Alignment.center,
                                            child: Container(
                                              height: 170.v,
                                              width: 214.h,
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                  107.h,
                                                ),
                                                border: Border.all(
                                                  color: theme.colorScheme
                                                      .onPrimaryContainer,
                                                  width: 2.h,
                                                ),
                                                gradient: LinearGradient(
                                                  begin: Alignment(0.5, 0),
                                                  end: Alignment(0.5, 1),
                                                  colors: [
                                                    appTheme.lightGreenA4003f,
                                                    appTheme.lightGreenA4003f,
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        CustomImageView(
                                          imagePath: ImageConstant.imgMap,
                                          height: 163.v,
                                          width: 156.h,
                                          alignment: Alignment.centerRight,
                                          margin: EdgeInsets.only(right: 22.h),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  imagePath: ImageConstant.imgGreenTruck,
                                  height: 122.v,
                                  width: 114.h,
                                  alignment: Alignment.topLeft,
                                  margin: EdgeInsets.only(
                                    left: 142.h,
                                    top: 92.v,
                                  ),
                                ),
                                CustomImageView(
                                  imagePath: ImageConstant.imgUserFeedback,
                                  height: 146.v,
                                  width: 176.h,
                                  alignment: Alignment.topRight,
                                  margin: EdgeInsets.only(
                                    top: 66.v,
                                    right: 26.h,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildThirtySixSection(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 2.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            height: 173.v,
            width: 214.h,
            margin: EdgeInsets.only(
              top: 31.v,
              bottom: 20.v,
            ),
            child: Stack(
              alignment: Alignment.centerRight,
              children: [
                Opacity(
                  opacity: 0.5,
                  child: Align(
                    alignment: Alignment.center,
                    child: Container(
                      height: 173.v,
                      width: 214.h,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(
                          107.h,
                        ),
                        border: Border.all(
                          color: theme.colorScheme.onPrimaryContainer,
                          width: 2.h,
                        ),
                        gradient: LinearGradient(
                          begin: Alignment(0.5, 0),
                          end: Alignment(0.5, 1),
                          colors: [
                            appTheme.lightGreenA4003f,
                            appTheme.lightGreenA4003f,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                CustomImageView(
                  imagePath: ImageConstant.imgComplaint,
                  height: 134.v,
                  width: 132.h,
                  alignment: Alignment.centerRight,
                  margin: EdgeInsets.only(right: 25.h),
                ),
              ],
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgHappyThankfulMan,
            height: 220.v,
            width: 308.h,
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildSeventyFourSection(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 30.h,
        right: 20.h,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "lbl_complaints".tr,
            style: CustomTextStyles.displayMediumOnPrimaryContainer,
          ),
          Text(
            "lbl_requests".tr,
            style: CustomTextStyles.displayMediumOnPrimaryContainer,
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildFiftyEightSection(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: SizedBox(
        height: 459.v,
        width: 594.h,
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgGreenInfographics459x594,
              height: 459.v,
              width: 594.h,
              alignment: Alignment.center,
            ),
            Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: EdgeInsets.fromLTRB(20.h, 116.v, 15.h, 261.v),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 81.v,
                      width: 155.h,
                      child: Stack(
                        alignment: Alignment.bottomCenter,
                        children: [
                          Align(
                            alignment: Alignment.topCenter,
                            child: Text(
                              "lbl_vehicle".tr,
                              style: CustomTextStyles
                                  .displayMediumOnPrimaryContainer,
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Text(
                              "lbl_proximity".tr,
                              style: CustomTextStyles
                                  .displayMediumOnPrimaryContainer,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(
                        top: 7.v,
                        bottom: 25.v,
                      ),
                      child: Text(
                        "lbl_feedback".tr,
                        style: CustomTextStyles.displayMediumOnPrimaryContainer,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
