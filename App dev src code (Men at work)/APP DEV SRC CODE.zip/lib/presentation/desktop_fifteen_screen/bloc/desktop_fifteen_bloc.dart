import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_fifteen_screen/models/desktop_fifteen_model.dart';
part 'desktop_fifteen_event.dart';
part 'desktop_fifteen_state.dart';

/// A bloc that manages the state of a DesktopFifteen according to the event that is dispatched to it.
class DesktopFifteenBloc
    extends Bloc<DesktopFifteenEvent, DesktopFifteenState> {
  DesktopFifteenBloc(DesktopFifteenState initialState) : super(initialState) {
    on<DesktopFifteenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopFifteenInitialEvent event,
    Emitter<DesktopFifteenState> emit,
  ) async {
    emit(state.copyWith(
      improveController: TextEditingController(),
    ));
  }
}
