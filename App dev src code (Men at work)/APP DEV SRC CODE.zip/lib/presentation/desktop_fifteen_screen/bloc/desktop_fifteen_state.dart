// ignore_for_file: must_be_immutable

part of 'desktop_fifteen_bloc.dart';

/// Represents the state of DesktopFifteen in the application.
class DesktopFifteenState extends Equatable {
  DesktopFifteenState({
    this.improveController,
    this.desktopFifteenModelObj,
  });

  TextEditingController? improveController;

  DesktopFifteenModel? desktopFifteenModelObj;

  @override
  List<Object?> get props => [
        improveController,
        desktopFifteenModelObj,
      ];

  DesktopFifteenState copyWith({
    TextEditingController? improveController,
    DesktopFifteenModel? desktopFifteenModelObj,
  }) {
    return DesktopFifteenState(
      improveController: improveController ?? this.improveController,
      desktopFifteenModelObj:
          desktopFifteenModelObj ?? this.desktopFifteenModelObj,
    );
  }
}
