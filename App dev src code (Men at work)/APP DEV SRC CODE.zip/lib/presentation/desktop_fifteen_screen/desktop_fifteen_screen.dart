import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/widgets/custom_elevated_button.dart';
import 'package:waste_guard/widgets/custom_text_form_field.dart';
import 'bloc/desktop_fifteen_bloc.dart';
import 'models/desktop_fifteen_model.dart';

class DesktopFifteenScreen extends StatelessWidget {
  const DesktopFifteenScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopFifteenBloc>(
      create: (context) => DesktopFifteenBloc(DesktopFifteenState(
        desktopFifteenModelObj: DesktopFifteenModel(),
      ))
        ..add(DesktopFifteenInitialEvent()),
      child: DesktopFifteenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        resizeToAvoidBottomInset: false,
        body: Container(
          width: SizeUtils.width,
          height: SizeUtils.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment(0.5, 0),
              end: Alignment(0.5, 1),
              colors: [
                appTheme.greenA200,
                appTheme.greenA200.withOpacity(0.67),
                appTheme.greenA200.withOpacity(0),
              ],
            ),
          ),
          child: SizedBox(
            height: 1067.v,
            width: 594.h,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgWhatIsAWaste,
                  height: 1069.v,
                  width: 594.h,
                  alignment: Alignment.center,
                ),
                Align(
                  alignment: Alignment.center,
                  child: SingleChildScrollView(
                    child: Container(
                      height: 1030.v,
                      width: 594.h,
                      margin: EdgeInsets.only(bottom: 2.v),
                      child: Stack(
                        alignment: Alignment.bottomCenter,
                        children: [
                          _buildFeedbackSection(context),
                          CustomImageView(
                            imagePath: ImageConstant.imgGreenInfographics,
                            height: 504.v,
                            width: 594.h,
                            alignment: Alignment.bottomCenter,
                          ),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              margin: EdgeInsets.only(
                                left: 53.h,
                                right: 70.h,
                                bottom: 200.v,
                              ),
                              padding: EdgeInsets.symmetric(
                                horizontal: 16.h,
                                vertical: 21.v,
                              ),
                              decoration: AppDecoration.fillWhiteA.copyWith(
                                borderRadius: BorderRadiusStyle.roundedBorder35,
                              ),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 3.v),
                                  Text(
                                    "msg_we_are_always_looking".tr,
                                    style: theme.textTheme.headlineLarge,
                                  ),
                                  SizedBox(
                                    height: 133.v,
                                    width: 382.h,
                                    child: Stack(
                                      alignment: Alignment.topCenter,
                                      children: [
                                        Align(
                                          alignment: Alignment.bottomLeft,
                                          child: Padding(
                                            padding: EdgeInsets.only(left: 1.h),
                                            child: Text(
                                              "lbl_think".tr,
                                              style:
                                                  theme.textTheme.headlineLarge,
                                            ),
                                          ),
                                        ),
                                        Align(
                                          alignment: Alignment.topCenter,
                                          child: SizedBox(
                                            height: 98.v,
                                            width: 382.h,
                                            child: Stack(
                                              alignment: Alignment.centerLeft,
                                              children: [
                                                Align(
                                                  alignment: Alignment.topLeft,
                                                  child: Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 1.h),
                                                    child: Text(
                                                      "msg_to_improve_your".tr,
                                                      style: theme.textTheme
                                                          .headlineLarge,
                                                    ),
                                                  ),
                                                ),
                                                Align(
                                                  alignment:
                                                      Alignment.centerLeft,
                                                  child: Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 1.h),
                                                    child: Text(
                                                      "msg_please_take_a_moment"
                                                          .tr,
                                                      style: theme.textTheme
                                                          .headlineLarge,
                                                    ),
                                                  ),
                                                ),
                                                Align(
                                                  alignment:
                                                      Alignment.bottomCenter,
                                                  child: Text(
                                                    "msg_evaluate_and_tell".tr,
                                                    style: theme.textTheme
                                                        .headlineLarge,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 2.v),
                                  Padding(
                                    padding: EdgeInsets.only(
                                      left: 23.h,
                                      right: 9.h,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        CustomImageView(
                                          imagePath:
                                              ImageConstant.imgChristmasStar,
                                          height: 48.v,
                                          width: 53.h,
                                        ),
                                        CustomImageView(
                                          imagePath:
                                              ImageConstant.imgChristmasStar,
                                          height: 48.v,
                                          width: 53.h,
                                          margin: EdgeInsets.only(left: 30.h),
                                        ),
                                        Spacer(
                                          flex: 32,
                                        ),
                                        CustomImageView(
                                          imagePath:
                                              ImageConstant.imgChristmasStar,
                                          height: 48.v,
                                          width: 53.h,
                                        ),
                                        Spacer(
                                          flex: 37,
                                        ),
                                        CustomImageView(
                                          imagePath:
                                              ImageConstant.imgChristmasStar,
                                          height: 48.v,
                                          width: 53.h,
                                        ),
                                        Spacer(
                                          flex: 30,
                                        ),
                                        CustomImageView(
                                          imagePath:
                                              ImageConstant.imgChristmasStar,
                                          height: 48.v,
                                          width: 53.h,
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 23.v),
                                  BlocSelector<
                                      DesktopFifteenBloc,
                                      DesktopFifteenState,
                                      TextEditingController?>(
                                    selector: (state) =>
                                        state.improveController,
                                    builder: (context, improveController) {
                                      return CustomTextFormField(
                                        controller: improveController,
                                        hintText: "msg_what_can_we_do_to".tr,
                                        textInputAction: TextInputAction.done,
                                        maxLines: 5,
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: 19.h,
                                          vertical: 3.v,
                                        ),
                                        borderDecoration:
                                            TextFormFieldStyleHelper
                                                .fillBlueGray,
                                      );
                                    },
                                  ),
                                  SizedBox(height: 16.v),
                                  CustomElevatedButton(
                                    height: 91.v,
                                    text: "lbl_submit".tr,
                                    margin: EdgeInsets.only(left: 6.h),
                                    buttonStyle:
                                        CustomButtonStyles.outlinePrimaryTL45,
                                    buttonTextStyle:
                                        CustomTextStyles.displayMedium48,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFeedbackSection(BuildContext context) {
    return Align(
      alignment: Alignment.topLeft,
      child: Padding(
        padding: EdgeInsets.only(
          left: 21.h,
          right: 41.h,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgBack,
              height: 64.adaptSize,
              width: 64.adaptSize,
            ),
            SizedBox(height: 32.v),
            Align(
              alignment: Alignment.centerRight,
              child: Text(
                "msg_we_appreciate_your".tr,
                textAlign: TextAlign.right,
                style: theme.textTheme.displayLarge,
              ),
            ),
            Align(
              alignment: Alignment.center,
              child: Text(
                "lbl_feedback2".tr,
                style: theme.textTheme.displayLarge,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
