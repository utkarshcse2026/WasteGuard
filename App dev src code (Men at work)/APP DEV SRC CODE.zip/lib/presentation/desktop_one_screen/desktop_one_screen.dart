import 'package:flutter/material.dart';
import 'package:flutter_svg_provider/flutter_svg_provider.dart' as fs;
import 'package:waste_guard/core/app_export.dart';
import 'bloc/desktop_one_bloc.dart';
import 'models/desktop_one_model.dart';

class DesktopOneScreen extends StatelessWidget {
  const DesktopOneScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopOneBloc>(
        create: (context) => DesktopOneBloc(
            DesktopOneState(desktopOneModelObj: DesktopOneModel()))
          ..add(DesktopOneInitialEvent()),
        child: DesktopOneScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DesktopOneBloc, DesktopOneState>(
        builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              extendBody: true,
              extendBodyBehindAppBar: true,
              body: Container(
                  width: SizeUtils.width,
                  height: SizeUtils.height,
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment(0.5, 0),
                          end: Alignment(0.5, 1),
                          colors: [
                        appTheme.greenA200,
                        appTheme.greenA200.withOpacity(0.67),
                        appTheme.greenA200.withOpacity(0)
                      ])),
                  child: _buildWasteGuardText(context))));
    });
  }

  /// Section Widget
  Widget _buildWasteGuardText(BuildContext context) {
    return SizedBox(
        height: 106.v,
        width: 594.h,
        child: Stack(alignment: Alignment.bottomCenter, children: [
          CustomImageView(
              imagePath: ImageConstant.imgWhatIsAWaste,
              height: 1069.v,
              width: 594.h,
              alignment: Alignment.center),
          Align(
              alignment: Alignment.bottomCenter,
              child: SingleChildScrollView(
                  child: Container(
                      height: 964.v,
                      width: 594.h,
                      margin: EdgeInsets.only(bottom: 21.v),
                      child:
                          Stack(alignment: Alignment.bottomCenter, children: [
                        Align(
                            alignment: Alignment.topCenter,
                            child: Container(
                                margin: EdgeInsets.only(right: 2.h),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 55.h, vertical: 105.v),
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                        image: fs.Svg(ImageConstant.imgGroup4),
                                        fit: BoxFit.cover)),
                                child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      SizedBox(height: 16.v),
                                      Text("lbl_waste_guard".tr,
                                          style: theme.textTheme.displayMedium)
                                    ]))),
                        Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                                height: 358.adaptSize,
                                width: 358.adaptSize,
                                margin: EdgeInsets.only(bottom: 81.v),
                                child: Stack(
                                    alignment: Alignment.bottomCenter,
                                    children: [
                                      CustomImageView(
                                          imagePath:
                                              ImageConstant.imgMobileBankingApp,
                                          height: 358.adaptSize,
                                          width: 358.adaptSize,
                                          alignment: Alignment.center),
                                      Align(
                                          alignment: Alignment.bottomCenter,
                                          child: Container(
                                              margin:
                                                  EdgeInsets.only(bottom: 30.v),
                                              decoration:
                                                  AppDecoration.outlinePrimary,
                                              child: Text("lbl_get_started".tr,
                                                  style: theme.textTheme
                                                      .displayMedium)))
                                    ]))),
                        CustomImageView(
                            imagePath: ImageConstant.imgSlideUp,
                            height: 101.v,
                            width: 100.h,
                            alignment: Alignment.bottomCenter)
                      ]))))
        ]));
  }
}
