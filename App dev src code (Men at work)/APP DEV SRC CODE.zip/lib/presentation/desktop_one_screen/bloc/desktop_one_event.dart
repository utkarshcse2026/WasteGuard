// ignore_for_file: must_be_immutable

part of 'desktop_one_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///DesktopOne widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class DesktopOneEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the DesktopOne widget is first created.
class DesktopOneInitialEvent extends DesktopOneEvent {
  @override
  List<Object?> get props => [];
}
