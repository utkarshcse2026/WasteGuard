import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_one_screen/models/desktop_one_model.dart';
part 'desktop_one_event.dart';
part 'desktop_one_state.dart';

/// A bloc that manages the state of a DesktopOne according to the event that is dispatched to it.
class DesktopOneBloc extends Bloc<DesktopOneEvent, DesktopOneState> {
  DesktopOneBloc(DesktopOneState initialState) : super(initialState) {
    on<DesktopOneInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopOneInitialEvent event,
    Emitter<DesktopOneState> emit,
  ) async {
    Future.delayed(const Duration(milliseconds: 3000), () {
      NavigatorService.popAndPushNamed(
        AppRoutes.desktopTwoScreen,
      );
    });
  }
}
