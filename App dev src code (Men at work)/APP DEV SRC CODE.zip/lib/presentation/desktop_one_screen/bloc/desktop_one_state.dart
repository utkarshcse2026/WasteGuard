// ignore_for_file: must_be_immutable

part of 'desktop_one_bloc.dart';

/// Represents the state of DesktopOne in the application.
class DesktopOneState extends Equatable {
  DesktopOneState({this.desktopOneModelObj});

  DesktopOneModel? desktopOneModelObj;

  @override
  List<Object?> get props => [
        desktopOneModelObj,
      ];

  DesktopOneState copyWith({DesktopOneModel? desktopOneModelObj}) {
    return DesktopOneState(
      desktopOneModelObj: desktopOneModelObj ?? this.desktopOneModelObj,
    );
  }
}
