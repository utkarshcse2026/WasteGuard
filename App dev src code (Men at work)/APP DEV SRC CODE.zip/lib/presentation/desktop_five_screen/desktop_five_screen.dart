import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/widgets/custom_elevated_button.dart';
import 'package:waste_guard/widgets/custom_pin_code_text_field.dart';
import 'bloc/desktop_five_bloc.dart';
import 'models/desktop_five_model.dart';

class DesktopFiveScreen extends StatelessWidget {
  const DesktopFiveScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopFiveBloc>(
      create: (context) => DesktopFiveBloc(DesktopFiveState(
        desktopFiveModelObj: DesktopFiveModel(),
      ))
        ..add(DesktopFiveInitialEvent()),
      child: DesktopFiveScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: 594.h,
          child: Column(
            children: [
              SizedBox(height: 37.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.imgBack,
                        height: 64.adaptSize,
                        width: 64.adaptSize,
                        margin: EdgeInsets.only(left: 21.h),
                      ),
                      SizedBox(height: 96.v),
                      SizedBox(
                        height: 870.v,
                        width: 594.h,
                        child: Stack(
                          alignment: Alignment.topCenter,
                          children: [
                            CustomImageView(
                              imagePath:
                                  ImageConstant.imgGreenInfographics459x594,
                              height: 459.v,
                              width: 594.h,
                              alignment: Alignment.bottomCenter,
                            ),
                            _buildOtpViewSection(context),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildOtpViewSection(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 41.h),
        padding: EdgeInsets.symmetric(
          horizontal: 12.h,
          vertical: 62.v,
        ),
        decoration: AppDecoration.fillGreen.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder50,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "msg_we_have_send_you".tr,
              textAlign: TextAlign.right,
              style: CustomTextStyles.headlineLarge30,
            ),
            Padding(
              padding: EdgeInsets.only(left: 127.h),
              child: Text(
                "lbl_123_80".tr,
                style: CustomTextStyles.displayMediumOnPrimaryContainer48,
              ),
            ),
            SizedBox(height: 13.v),
            Padding(
              padding: EdgeInsets.only(left: 57.h),
              child: Text(
                "msg_enter_the_code_here".tr,
                style: theme.textTheme.displaySmall,
              ),
            ),
            SizedBox(height: 25.v),
            Padding(
              padding: EdgeInsets.only(
                left: 3.h,
                right: 22.h,
              ),
              child: BlocSelector<DesktopFiveBloc, DesktopFiveState,
                  TextEditingController?>(
                selector: (state) => state.otpController,
                builder: (context, otpController) {
                  return CustomPinCodeTextField(
                    context: context,
                    controller: otpController,
                    onChanged: (value) {
                      otpController?.text = value;
                    },
                  );
                },
              ),
            ),
            SizedBox(height: 36.v),
            CustomElevatedButton(
              height: 82.v,
              text: "lbl_verify".tr,
              margin: EdgeInsets.only(
                left: 30.h,
                right: 37.h,
              ),
              buttonStyle: CustomButtonStyles.outlinePrimary,
              alignment: Alignment.center,
            ),
            SizedBox(height: 10.v),
          ],
        ),
      ),
    );
  }
}
