// ignore_for_file: must_be_immutable

part of 'desktop_five_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///DesktopFive widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class DesktopFiveEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the DesktopFive widget is first created.
class DesktopFiveInitialEvent extends DesktopFiveEvent {
  @override
  List<Object?> get props => [];
}

///event for OTP auto fill
class ChangeOTPEvent extends DesktopFiveEvent {
  ChangeOTPEvent({required this.code});

  String code;

  @override
  List<Object?> get props => [
        code,
      ];
}
