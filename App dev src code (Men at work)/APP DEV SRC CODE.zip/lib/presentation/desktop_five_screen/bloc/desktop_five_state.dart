// ignore_for_file: must_be_immutable

part of 'desktop_five_bloc.dart';

/// Represents the state of DesktopFive in the application.
class DesktopFiveState extends Equatable {
  DesktopFiveState({
    this.otpController,
    this.desktopFiveModelObj,
  });

  TextEditingController? otpController;

  DesktopFiveModel? desktopFiveModelObj;

  @override
  List<Object?> get props => [
        otpController,
        desktopFiveModelObj,
      ];

  DesktopFiveState copyWith({
    TextEditingController? otpController,
    DesktopFiveModel? desktopFiveModelObj,
  }) {
    return DesktopFiveState(
      otpController: otpController ?? this.otpController,
      desktopFiveModelObj: desktopFiveModelObj ?? this.desktopFiveModelObj,
    );
  }
}
