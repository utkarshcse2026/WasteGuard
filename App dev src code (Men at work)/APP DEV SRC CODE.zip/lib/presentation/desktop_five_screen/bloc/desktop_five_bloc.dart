import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_five_screen/models/desktop_five_model.dart';
import 'package:sms_autofill/sms_autofill.dart';
part 'desktop_five_event.dart';
part 'desktop_five_state.dart';

/// A bloc that manages the state of a DesktopFive according to the event that is dispatched to it.
class DesktopFiveBloc extends Bloc<DesktopFiveEvent, DesktopFiveState>
    with CodeAutoFill {
  DesktopFiveBloc(DesktopFiveState initialState) : super(initialState) {
    on<DesktopFiveInitialEvent>(_onInitialize);
    on<ChangeOTPEvent>(_changeOTP);
  }

  @override
  codeUpdated() {
    add(ChangeOTPEvent(code: code!));
  }

  _changeOTP(
    ChangeOTPEvent event,
    Emitter<DesktopFiveState> emit,
  ) {
    emit(state.copyWith(
      otpController: TextEditingController(text: event.code),
    ));
  }

  _onInitialize(
    DesktopFiveInitialEvent event,
    Emitter<DesktopFiveState> emit,
  ) async {
    emit(state.copyWith(
      otpController: TextEditingController(),
    ));
    listenForCode();
  }
}
