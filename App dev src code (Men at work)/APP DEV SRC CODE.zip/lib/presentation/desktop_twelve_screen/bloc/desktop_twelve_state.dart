// ignore_for_file: must_be_immutable

part of 'desktop_twelve_bloc.dart';

/// Represents the state of DesktopTwelve in the application.
class DesktopTwelveState extends Equatable {
  DesktopTwelveState({this.desktopTwelveModelObj});

  DesktopTwelveModel? desktopTwelveModelObj;

  @override
  List<Object?> get props => [
        desktopTwelveModelObj,
      ];

  DesktopTwelveState copyWith({DesktopTwelveModel? desktopTwelveModelObj}) {
    return DesktopTwelveState(
      desktopTwelveModelObj:
          desktopTwelveModelObj ?? this.desktopTwelveModelObj,
    );
  }
}
