import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_twelve_screen/models/desktop_twelve_model.dart';
part 'desktop_twelve_event.dart';
part 'desktop_twelve_state.dart';

/// A bloc that manages the state of a DesktopTwelve according to the event that is dispatched to it.
class DesktopTwelveBloc extends Bloc<DesktopTwelveEvent, DesktopTwelveState> {
  DesktopTwelveBloc(DesktopTwelveState initialState) : super(initialState) {
    on<DesktopTwelveInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopTwelveInitialEvent event,
    Emitter<DesktopTwelveState> emit,
  ) async {}
}
