import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/widgets/custom_elevated_button.dart';
import 'bloc/desktop_twelve_bloc.dart';
import 'models/desktop_twelve_model.dart';

class DesktopTwelveScreen extends StatelessWidget {
  const DesktopTwelveScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopTwelveBloc>(
      create: (context) => DesktopTwelveBloc(DesktopTwelveState(
        desktopTwelveModelObj: DesktopTwelveModel(),
      ))
        ..add(DesktopTwelveInitialEvent()),
      child: DesktopTwelveScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DesktopTwelveBloc, DesktopTwelveState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: SizedBox(
              width: 594.h,
              child: Column(
                children: [
                  SizedBox(height: 53.v),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.maxFinite,
                            margin: EdgeInsets.only(right: 164.h),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgBack,
                                  height: 64.adaptSize,
                                  width: 64.adaptSize,
                                  margin: EdgeInsets.only(bottom: 79.v),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(
                                    left: 82.h,
                                    top: 47.v,
                                  ),
                                  child: Text(
                                    "lbl_requests2".tr,
                                    style: CustomTextStyles
                                        .akayaKanadakaOnPrimaryContainer,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 34.v),
                          SizedBox(
                            height: 836.v,
                            width: 594.h,
                            child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                CustomImageView(
                                  imagePath:
                                      ImageConstant.imgGreenInfographics459x594,
                                  height: 459.v,
                                  width: 594.h,
                                  alignment: Alignment.bottomCenter,
                                ),
                                Align(
                                  alignment: Alignment.topCenter,
                                  child: Container(
                                    margin:
                                        EdgeInsets.symmetric(horizontal: 57.h),
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 32.h,
                                      vertical: 51.v,
                                    ),
                                    decoration: AppDecoration
                                        .fillSecondaryContainer
                                        .copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder45,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Container(
                                          width: 414.h,
                                          margin: EdgeInsets.only(left: 1.h),
                                          padding: EdgeInsets.symmetric(
                                            horizontal: 18.h,
                                            vertical: 37.v,
                                          ),
                                          decoration: AppDecoration
                                              .outlinePrimary2
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder20,
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "msg_describe_your_request".tr,
                                                style: theme
                                                    .textTheme.displaySmall,
                                              ),
                                              SizedBox(height: 57.v),
                                              Text(
                                                "lbl_in_detail".tr,
                                                style: theme
                                                    .textTheme.displaySmall,
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(height: 32.v),
                                        Container(
                                          width: 414.h,
                                          margin: EdgeInsets.only(left: 1.h),
                                          padding: EdgeInsets.symmetric(
                                            horizontal: 19.h,
                                            vertical: 12.v,
                                          ),
                                          decoration: AppDecoration
                                              .outlinePrimary2
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder20,
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              SizedBox(height: 2.v),
                                              Text(
                                                "msg_address_area_pincode".tr,
                                                style: theme
                                                    .textTheme.displaySmall,
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(height: 32.v),
                                        Container(
                                          width: 414.h,
                                          margin: EdgeInsets.only(left: 1.h),
                                          padding: EdgeInsets.symmetric(
                                            horizontal: 19.h,
                                            vertical: 13.v,
                                          ),
                                          decoration: AppDecoration
                                              .outlinePrimary2
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder20,
                                          ),
                                          child: Text(
                                            "msg_geotagging_image".tr,
                                            style: theme.textTheme.displaySmall,
                                          ),
                                        ),
                                        SizedBox(height: 18.v),
                                        CustomElevatedButton(
                                          text: "lbl_submit".tr,
                                        ),
                                        SizedBox(height: 10.v),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
