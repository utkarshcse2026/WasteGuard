// ignore_for_file: must_be_immutable

part of 'desktop_thirteen_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///DesktopThirteen widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class DesktopThirteenEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the DesktopThirteen widget is first created.
class DesktopThirteenInitialEvent extends DesktopThirteenEvent {
  @override
  List<Object?> get props => [];
}
