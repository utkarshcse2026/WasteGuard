// ignore_for_file: must_be_immutable

part of 'desktop_thirteen_bloc.dart';

/// Represents the state of DesktopThirteen in the application.
class DesktopThirteenState extends Equatable {
  DesktopThirteenState({
    this.addressSectionController,
    this.stateSectionController,
    this.citySectionController,
    this.pincodeSectionController,
    this.desktopThirteenModelObj,
  });

  TextEditingController? addressSectionController;

  TextEditingController? stateSectionController;

  TextEditingController? citySectionController;

  TextEditingController? pincodeSectionController;

  DesktopThirteenModel? desktopThirteenModelObj;

  @override
  List<Object?> get props => [
        addressSectionController,
        stateSectionController,
        citySectionController,
        pincodeSectionController,
        desktopThirteenModelObj,
      ];

  DesktopThirteenState copyWith({
    TextEditingController? addressSectionController,
    TextEditingController? stateSectionController,
    TextEditingController? citySectionController,
    TextEditingController? pincodeSectionController,
    DesktopThirteenModel? desktopThirteenModelObj,
  }) {
    return DesktopThirteenState(
      addressSectionController:
          addressSectionController ?? this.addressSectionController,
      stateSectionController:
          stateSectionController ?? this.stateSectionController,
      citySectionController:
          citySectionController ?? this.citySectionController,
      pincodeSectionController:
          pincodeSectionController ?? this.pincodeSectionController,
      desktopThirteenModelObj:
          desktopThirteenModelObj ?? this.desktopThirteenModelObj,
    );
  }
}
