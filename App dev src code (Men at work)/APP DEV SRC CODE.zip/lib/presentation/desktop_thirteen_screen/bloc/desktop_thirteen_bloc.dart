import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_thirteen_screen/models/desktop_thirteen_model.dart';
part 'desktop_thirteen_event.dart';
part 'desktop_thirteen_state.dart';

/// A bloc that manages the state of a DesktopThirteen according to the event that is dispatched to it.
class DesktopThirteenBloc
    extends Bloc<DesktopThirteenEvent, DesktopThirteenState> {
  DesktopThirteenBloc(DesktopThirteenState initialState) : super(initialState) {
    on<DesktopThirteenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopThirteenInitialEvent event,
    Emitter<DesktopThirteenState> emit,
  ) async {
    emit(state.copyWith(
      addressSectionController: TextEditingController(),
      stateSectionController: TextEditingController(),
      citySectionController: TextEditingController(),
      pincodeSectionController: TextEditingController(),
    ));
  }
}
