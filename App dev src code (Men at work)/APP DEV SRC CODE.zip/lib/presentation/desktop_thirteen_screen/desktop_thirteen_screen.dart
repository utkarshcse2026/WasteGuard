import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/core/utils/validation_functions.dart';
import 'package:waste_guard/widgets/custom_elevated_button.dart';
import 'package:waste_guard/widgets/custom_text_form_field.dart';
import 'bloc/desktop_thirteen_bloc.dart';
import 'models/desktop_thirteen_model.dart';

class DesktopThirteenScreen extends StatelessWidget {
  DesktopThirteenScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopThirteenBloc>(
      create: (context) => DesktopThirteenBloc(DesktopThirteenState(
        desktopThirteenModelObj: DesktopThirteenModel(),
      ))
        ..add(DesktopThirteenInitialEvent()),
      child: DesktopThirteenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: SizedBox(
            width: 594.h,
            child: Column(
              children: [
                SizedBox(height: 53.v),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildVehicleProximitySection(context),
                        SizedBox(height: 31.v),
                        SizedBox(
                          height: 836.v,
                          width: 594.h,
                          child: Stack(
                            alignment: Alignment.topCenter,
                            children: [
                              CustomImageView(
                                imagePath:
                                    ImageConstant.imgGreenInfographics459x594,
                                height: 459.v,
                                width: 594.h,
                                alignment: Alignment.bottomCenter,
                              ),
                              Align(
                                alignment: Alignment.topCenter,
                                child: Container(
                                  margin:
                                      EdgeInsets.symmetric(horizontal: 57.h),
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 32.h,
                                    vertical: 53.v,
                                  ),
                                  decoration: AppDecoration.fillGreen.copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder45,
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      SizedBox(height: 11.v),
                                      _buildAddressSection(context),
                                      SizedBox(height: 30.v),
                                      _buildStateSection(context),
                                      SizedBox(height: 27.v),
                                      _buildCitySection(context),
                                      SizedBox(height: 30.v),
                                      _buildPincodeSection(context),
                                      SizedBox(height: 20.v),
                                      Container(
                                        width: 414.h,
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 19.h,
                                          vertical: 6.v,
                                        ),
                                        decoration: AppDecoration
                                            .outlinePrimary2
                                            .copyWith(
                                          borderRadius:
                                              BorderRadiusStyle.roundedBorder20,
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            SizedBox(height: 15.v),
                                            Text(
                                              "lbl_correct_address".tr,
                                              style:
                                                  theme.textTheme.displaySmall,
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(height: 21.v),
                                      _buildSubmitButtonSection(context),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildVehicleProximitySection(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 65.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgBack,
            height: 64.adaptSize,
            width: 64.adaptSize,
            margin: EdgeInsets.only(bottom: 82.v),
          ),
          Container(
            height: 106.v,
            width: 451.h,
            margin: EdgeInsets.only(
              left: 14.h,
              top: 40.v,
            ),
            child: Stack(
              alignment: Alignment.bottomRight,
              children: [
                Align(
                  alignment: Alignment.topCenter,
                  child: Text(
                    "msg_vehicle_proximity".tr,
                    style: CustomTextStyles.displayLargeOnPrimaryContainer,
                  ),
                ),
                Align(
                  alignment: Alignment.bottomRight,
                  child: Padding(
                    padding: EdgeInsets.only(right: 21.h),
                    child: Text(
                      "lbl_find_distance".tr,
                      style: CustomTextStyles.displayMediumOnPrimary40,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildAddressSection(BuildContext context) {
    return BlocSelector<DesktopThirteenBloc, DesktopThirteenState,
        TextEditingController?>(
      selector: (state) => state.addressSectionController,
      builder: (context, addressSectionController) {
        return CustomTextFormField(
          controller: addressSectionController,
          hintText: "msg_enter_your_country".tr,
        );
      },
    );
  }

  /// Section Widget
  Widget _buildStateSection(BuildContext context) {
    return BlocSelector<DesktopThirteenBloc, DesktopThirteenState,
        TextEditingController?>(
      selector: (state) => state.stateSectionController,
      builder: (context, stateSectionController) {
        return CustomTextFormField(
          controller: stateSectionController,
          hintText: "msg_enter_your_state".tr,
        );
      },
    );
  }

  /// Section Widget
  Widget _buildCitySection(BuildContext context) {
    return BlocSelector<DesktopThirteenBloc, DesktopThirteenState,
        TextEditingController?>(
      selector: (state) => state.citySectionController,
      builder: (context, citySectionController) {
        return CustomTextFormField(
          controller: citySectionController,
          hintText: "lbl_enter_your_city".tr,
        );
      },
    );
  }

  /// Section Widget
  Widget _buildPincodeSection(BuildContext context) {
    return BlocSelector<DesktopThirteenBloc, DesktopThirteenState,
        TextEditingController?>(
      selector: (state) => state.pincodeSectionController,
      builder: (context, pincodeSectionController) {
        return CustomTextFormField(
          controller: pincodeSectionController,
          hintText: "msg_enter_your_area".tr,
          textInputAction: TextInputAction.done,
          textInputType: TextInputType.number,
          validator: (value) {
            if (!isNumeric(value)) {
              return "err_msg_please_enter_valid_number".tr;
            }
            return null;
          },
        );
      },
    );
  }

  /// Section Widget
  Widget _buildSubmitButtonSection(BuildContext context) {
    return CustomElevatedButton(
      text: "lbl_submit".tr,
    );
  }
}
