// ignore_for_file: must_be_immutable

part of 'desktop_nine_bloc.dart';

/// Represents the state of DesktopNine in the application.
class DesktopNineState extends Equatable {
  DesktopNineState({this.desktopNineModelObj});

  DesktopNineModel? desktopNineModelObj;

  @override
  List<Object?> get props => [
        desktopNineModelObj,
      ];

  DesktopNineState copyWith({DesktopNineModel? desktopNineModelObj}) {
    return DesktopNineState(
      desktopNineModelObj: desktopNineModelObj ?? this.desktopNineModelObj,
    );
  }
}
