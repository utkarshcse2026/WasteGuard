// ignore_for_file: must_be_immutable

part of 'desktop_nine_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///DesktopNine widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class DesktopNineEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the DesktopNine widget is first created.
class DesktopNineInitialEvent extends DesktopNineEvent {
  @override
  List<Object?> get props => [];
}
