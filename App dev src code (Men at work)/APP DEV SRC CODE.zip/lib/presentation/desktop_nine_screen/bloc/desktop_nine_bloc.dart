import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_nine_screen/models/desktop_nine_model.dart';
part 'desktop_nine_event.dart';
part 'desktop_nine_state.dart';

/// A bloc that manages the state of a DesktopNine according to the event that is dispatched to it.
class DesktopNineBloc extends Bloc<DesktopNineEvent, DesktopNineState> {
  DesktopNineBloc(DesktopNineState initialState) : super(initialState) {
    on<DesktopNineInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopNineInitialEvent event,
    Emitter<DesktopNineState> emit,
  ) async {}
}
