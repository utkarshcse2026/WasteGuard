import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/widgets/custom_elevated_button.dart';
import 'bloc/desktop_nine_bloc.dart';
import 'models/desktop_nine_model.dart';

class DesktopNineScreen extends StatelessWidget {
  const DesktopNineScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopNineBloc>(
      create: (context) => DesktopNineBloc(DesktopNineState(
        desktopNineModelObj: DesktopNineModel(),
      ))
        ..add(DesktopNineInitialEvent()),
      child: DesktopNineScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DesktopNineBloc, DesktopNineState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: SizedBox(
              width: 594.h,
              child: Column(
                children: [
                  SizedBox(height: 37.v),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildComplaintsRow(context),
                          SizedBox(
                            height: 896.v,
                            width: 594.h,
                            child: Stack(
                              alignment: Alignment.topRight,
                              children: [
                                CustomImageView(
                                  imagePath:
                                      ImageConstant.imgGreenInfographics459x594,
                                  height: 459.v,
                                  width: 594.h,
                                  alignment: Alignment.bottomCenter,
                                ),
                                Align(
                                  alignment: Alignment.topRight,
                                  child: Padding(
                                    padding: EdgeInsets.only(right: 72.h),
                                    child: Text(
                                      "lbl_category".tr,
                                      style:
                                          CustomTextStyles.displayMediumLime900,
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  imagePath: ImageConstant.imgRobotNavigator,
                                  height: 323.v,
                                  width: 307.h,
                                  alignment: Alignment.centerLeft,
                                  margin: EdgeInsets.only(left: 15.h),
                                ),
                                Opacity(
                                  opacity: 0.5,
                                  child: CustomImageView(
                                    imagePath: ImageConstant.imgEllipse9,
                                    height: 220.v,
                                    width: 252.h,
                                    alignment: Alignment.topLeft,
                                    margin: EdgeInsets.only(
                                      left: 32.h,
                                      top: 65.v,
                                    ),
                                  ),
                                ),
                                CustomImageView(
                                  imagePath: ImageConstant.imgGarbageBag,
                                  height: 290.v,
                                  width: 111.h,
                                  alignment: Alignment.topLeft,
                                  margin: EdgeInsets.only(
                                    left: 71.h,
                                    top: 29.v,
                                  ),
                                ),
                                CustomElevatedButton(
                                  width: 290.h,
                                  text: "lbl_dumping_side".tr,
                                  margin: EdgeInsets.only(
                                    top: 146.v,
                                    right: 10.h,
                                  ),
                                  buttonStyle: CustomButtonStyles.fillCyan,
                                  buttonTextStyle:
                                      CustomTextStyles.displayMedium40,
                                  alignment: Alignment.topRight,
                                ),
                                CustomElevatedButton(
                                  width: 290.h,
                                  text: "lbl_service".tr,
                                  margin: EdgeInsets.only(right: 10.h),
                                  buttonStyle: CustomButtonStyles.fillCyan,
                                  buttonTextStyle:
                                      CustomTextStyles.displayMedium48,
                                  alignment: Alignment.centerRight,
                                ),
                                CustomImageView(
                                  imagePath: ImageConstant.imgLandfill,
                                  height: 151.v,
                                  width: 215.h,
                                  alignment: Alignment.topLeft,
                                  margin: EdgeInsets.only(
                                    left: 69.h,
                                    top: 112.v,
                                  ),
                                ),
                                CustomImageView(
                                  imagePath: ImageConstant.imgGarbageTruck,
                                  height: 91.v,
                                  width: 157.h,
                                  alignment: Alignment.topLeft,
                                  margin: EdgeInsets.only(
                                    left: 158.h,
                                    top: 206.v,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildComplaintsRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 7.h,
        right: 72.h,
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgBack,
            height: 64.adaptSize,
            width: 64.adaptSize,
            margin: EdgeInsets.only(bottom: 69.v),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 9.h,
              top: 42.v,
            ),
            child: Text(
              "lbl_complaints2".tr,
              style: CustomTextStyles.akayaKanadakaOnPrimaryContainer,
            ),
          ),
        ],
      ),
    );
  }
}
