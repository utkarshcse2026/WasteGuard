import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'bloc/desktop_fourteen_bloc.dart';
import 'models/desktop_fourteen_model.dart';

class DesktopFourteenScreen extends StatelessWidget {
  const DesktopFourteenScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopFourteenBloc>(
      create: (context) => DesktopFourteenBloc(DesktopFourteenState(
        desktopFourteenModelObj: DesktopFourteenModel(),
      ))
        ..add(DesktopFourteenInitialEvent()),
      child: DesktopFourteenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DesktopFourteenBloc, DesktopFourteenState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            body: Container(
              width: SizeUtils.width,
              height: SizeUtils.height,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(
                    ImageConstant.imgGroup100,
                  ),
                  fit: BoxFit.cover,
                ),
              ),
              child: SizedBox(
                width: 594.h,
                child: Column(
                  children: [
                    SizedBox(height: 25.v),
                    Expanded(
                      child: SingleChildScrollView(
                        child: CustomImageView(
                          imagePath: ImageConstant.imgBack,
                          height: 25.v,
                          width: 594.h,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
