import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_fourteen_screen/models/desktop_fourteen_model.dart';
part 'desktop_fourteen_event.dart';
part 'desktop_fourteen_state.dart';

/// A bloc that manages the state of a DesktopFourteen according to the event that is dispatched to it.
class DesktopFourteenBloc
    extends Bloc<DesktopFourteenEvent, DesktopFourteenState> {
  DesktopFourteenBloc(DesktopFourteenState initialState) : super(initialState) {
    on<DesktopFourteenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopFourteenInitialEvent event,
    Emitter<DesktopFourteenState> emit,
  ) async {}
}
