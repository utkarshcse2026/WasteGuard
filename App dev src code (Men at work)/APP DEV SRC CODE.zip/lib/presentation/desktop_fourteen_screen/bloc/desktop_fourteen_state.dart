// ignore_for_file: must_be_immutable

part of 'desktop_fourteen_bloc.dart';

/// Represents the state of DesktopFourteen in the application.
class DesktopFourteenState extends Equatable {
  DesktopFourteenState({this.desktopFourteenModelObj});

  DesktopFourteenModel? desktopFourteenModelObj;

  @override
  List<Object?> get props => [
        desktopFourteenModelObj,
      ];

  DesktopFourteenState copyWith(
      {DesktopFourteenModel? desktopFourteenModelObj}) {
    return DesktopFourteenState(
      desktopFourteenModelObj:
          desktopFourteenModelObj ?? this.desktopFourteenModelObj,
    );
  }
}
