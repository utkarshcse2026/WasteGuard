// ignore_for_file: must_be_immutable

part of 'desktop_fourteen_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///DesktopFourteen widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class DesktopFourteenEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the DesktopFourteen widget is first created.
class DesktopFourteenInitialEvent extends DesktopFourteenEvent {
  @override
  List<Object?> get props => [];
}
