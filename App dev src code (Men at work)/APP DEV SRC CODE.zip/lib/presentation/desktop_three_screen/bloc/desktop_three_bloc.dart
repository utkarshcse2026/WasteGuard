import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_three_screen/models/desktop_three_model.dart';
part 'desktop_three_event.dart';
part 'desktop_three_state.dart';

/// A bloc that manages the state of a DesktopThree according to the event that is dispatched to it.
class DesktopThreeBloc extends Bloc<DesktopThreeEvent, DesktopThreeState> {
  DesktopThreeBloc(DesktopThreeState initialState) : super(initialState) {
    on<DesktopThreeInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopThreeInitialEvent event,
    Emitter<DesktopThreeState> emit,
  ) async {
    emit(state.copyWith(
      priceController: TextEditingController(),
    ));
  }
}
