// ignore_for_file: must_be_immutable

part of 'desktop_three_bloc.dart';

/// Represents the state of DesktopThree in the application.
class DesktopThreeState extends Equatable {
  DesktopThreeState({
    this.priceController,
    this.desktopThreeModelObj,
  });

  TextEditingController? priceController;

  DesktopThreeModel? desktopThreeModelObj;

  @override
  List<Object?> get props => [
        priceController,
        desktopThreeModelObj,
      ];

  DesktopThreeState copyWith({
    TextEditingController? priceController,
    DesktopThreeModel? desktopThreeModelObj,
  }) {
    return DesktopThreeState(
      priceController: priceController ?? this.priceController,
      desktopThreeModelObj: desktopThreeModelObj ?? this.desktopThreeModelObj,
    );
  }
}
