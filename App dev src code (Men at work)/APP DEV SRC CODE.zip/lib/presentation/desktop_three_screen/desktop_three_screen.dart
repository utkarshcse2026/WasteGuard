import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/core/utils/validation_functions.dart';
import 'package:waste_guard/widgets/custom_outlined_button.dart';
import 'package:waste_guard/widgets/custom_text_form_field.dart';
import 'bloc/desktop_three_bloc.dart';
import 'models/desktop_three_model.dart';

class DesktopThreeScreen extends StatelessWidget {
  DesktopThreeScreen({Key? key})
      : super(
          key: key,
        );

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopThreeBloc>(
      create: (context) => DesktopThreeBloc(DesktopThreeState(
        desktopThreeModelObj: DesktopThreeModel(),
      ))
        ..add(DesktopThreeInitialEvent()),
      child: DesktopThreeScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBody: true,
        extendBodyBehindAppBar: true,
        resizeToAvoidBottomInset: false,
        body: Container(
          width: SizeUtils.width,
          height: SizeUtils.height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment(0.5, 0),
              end: Alignment(0.5, 1),
              colors: [
                appTheme.greenA200,
                appTheme.greenA200.withOpacity(0.67),
                appTheme.greenA200.withOpacity(0),
              ],
            ),
          ),
          child: Form(
            key: _formKey,
            child: SizedBox(
              height: 1067.v,
              width: 594.h,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgWhatIsAWaste,
                    height: 1069.v,
                    width: 594.h,
                    alignment: Alignment.center,
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: SingleChildScrollView(
                      child: Container(
                        height: 1030.v,
                        width: 594.h,
                        margin: EdgeInsets.only(bottom: 2.v),
                        child: Stack(
                          alignment: Alignment.bottomCenter,
                          children: [
                            _buildLoginForm(context),
                            CustomImageView(
                              imagePath: ImageConstant.imgGreenInfographics,
                              height: 504.v,
                              width: 594.h,
                              alignment: Alignment.bottomCenter,
                            ),
                            _buildRegistrationForm(context),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildLoginForm(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Padding(
        padding: EdgeInsets.only(left: 21.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgBack,
              height: 64.adaptSize,
              width: 64.adaptSize,
            ),
            SizedBox(height: 46.v),
            Align(
              alignment: Alignment.centerRight,
              child: SizedBox(
                height: 188.v,
                width: 487.h,
                child: Stack(
                  alignment: Alignment.topLeft,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgCurvedGreenLeaf,
                      height: 188.v,
                      width: 274.h,
                      alignment: Alignment.centerRight,
                    ),
                    Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                        margin: EdgeInsets.only(
                          left: 26.h,
                          top: 41.v,
                        ),
                        decoration: AppDecoration.outlinePrimary,
                        child: Text(
                          "lbl_register".tr,
                          style: CustomTextStyles.akayaKanadakaWhiteA700,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomLeft,
                      child: Padding(
                        padding: EdgeInsets.only(bottom: 9.v),
                        child: Text(
                          "msg_create_your_new".tr,
                          style: CustomTextStyles.displaySmallWhiteA700,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildRegistrationForm(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        margin: EdgeInsets.only(
          left: 30.h,
          right: 30.h,
          bottom: 207.v,
        ),
        padding: EdgeInsets.symmetric(
          horizontal: 17.h,
          vertical: 9.v,
        ),
        decoration: AppDecoration.fillBlueGray.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder25,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height: 28.v),
            BlocSelector<DesktopThreeBloc, DesktopThreeState,
                TextEditingController?>(
              selector: (state) => state.priceController,
              builder: (context, priceController) {
                return CustomTextFormField(
                  controller: priceController,
                  hintText: "lbl_user_name".tr,
                  hintStyle: CustomTextStyles.displaySmall37,
                  textInputAction: TextInputAction.done,
                  validator: (value) {
                    if (!isText(value)) {
                      return "err_msg_please_enter_valid_text".tr;
                    }
                    return null;
                  },
                );
              },
            ),
            SizedBox(height: 33.v),
            Container(
              width: 498.h,
              padding: EdgeInsets.symmetric(
                horizontal: 75.h,
                vertical: 9.v,
              ),
              decoration: AppDecoration.outlineWhiteA.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder15,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 3.v),
                  Text(
                    "lbl_e_mail_i_d".tr,
                    style: CustomTextStyles.displayMediumOnPrimaryContainer,
                  ),
                ],
              ),
            ),
            SizedBox(height: 33.v),
            CustomOutlinedButton(
              text: "lbl_password".tr,
              buttonTextStyle: CustomTextStyles.displayMediumOnPrimaryContainer,
            ),
            SizedBox(height: 31.v),
            SizedBox(
              height: 138.v,
              width: 498.h,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: Padding(
                      padding: EdgeInsets.only(
                        left: 48.h,
                        bottom: 19.v,
                      ),
                      child: Text(
                        "lbl_remember_me".tr,
                        style: CustomTextStyles.headlineLarge30,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: SizedBox(
                      height: 138.v,
                      width: 498.h,
                      child: Stack(
                        alignment: Alignment.bottomLeft,
                        children: [
                          CustomOutlinedButton(
                            width: 498.h,
                            text: "lbl_proceed".tr,
                            buttonStyle: CustomButtonStyles.outlineGreen,
                            buttonTextStyle: CustomTextStyles.displayMedium48,
                            alignment: Alignment.topCenter,
                          ),
                          CustomImageView(
                            imagePath: ImageConstant.imgCheckmark,
                            height: 67.v,
                            width: 32.h,
                            alignment: Alignment.bottomLeft,
                            margin: EdgeInsets.only(left: 12.h),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
