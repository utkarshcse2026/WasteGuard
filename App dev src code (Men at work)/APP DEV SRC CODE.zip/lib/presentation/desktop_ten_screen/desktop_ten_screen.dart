import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/widgets/custom_elevated_button.dart';
import 'bloc/desktop_ten_bloc.dart';
import 'models/desktop_ten_model.dart';

class DesktopTenScreen extends StatelessWidget {
  const DesktopTenScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopTenBloc>(
      create: (context) => DesktopTenBloc(DesktopTenState(
        desktopTenModelObj: DesktopTenModel(),
      ))
        ..add(DesktopTenInitialEvent()),
      child: DesktopTenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DesktopTenBloc, DesktopTenState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: SizedBox(
              width: 594.h,
              child: Column(
                children: [
                  SizedBox(height: 53.v),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildComplaintsRow(context),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Padding(
                              padding: EdgeInsets.only(right: 90.h),
                              child: Text(
                                "lbl_dumping_side".tr,
                                style:
                                    CustomTextStyles.displayMediumOnPrimary40,
                              ),
                            ),
                          ),
                          SizedBox(height: 20.v),
                          SizedBox(
                            height: 836.v,
                            width: 594.h,
                            child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                CustomImageView(
                                  imagePath:
                                      ImageConstant.imgGreenInfographics459x594,
                                  height: 459.v,
                                  width: 594.h,
                                  alignment: Alignment.bottomCenter,
                                ),
                                Align(
                                  alignment: Alignment.topCenter,
                                  child: Container(
                                    margin:
                                        EdgeInsets.symmetric(horizontal: 57.h),
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 32.h,
                                      vertical: 53.v,
                                    ),
                                    decoration:
                                        AppDecoration.fillGreen.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder45,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SizedBox(height: 34.v),
                                        Container(
                                          width: 414.h,
                                          margin: EdgeInsets.only(left: 1.h),
                                          padding: EdgeInsets.symmetric(
                                            horizontal: 13.h,
                                            vertical: 23.v,
                                          ),
                                          decoration: AppDecoration
                                              .outlinePrimary2
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder20,
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "msg_describe_your_complaint"
                                                    .tr,
                                                style: theme
                                                    .textTheme.displaySmall,
                                              ),
                                              SizedBox(height: 88.v),
                                              Padding(
                                                padding:
                                                    EdgeInsets.only(left: 7.h),
                                                child: Text(
                                                  "lbl_in_detail".tr,
                                                  style: theme
                                                      .textTheme.displaySmall,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(height: 39.v),
                                        CustomElevatedButton(
                                          text: "msg_address_area_pincode".tr,
                                          buttonStyle: CustomButtonStyles
                                              .outlinePrimaryTL20,
                                          buttonTextStyle:
                                              theme.textTheme.displaySmall!,
                                        ),
                                        SizedBox(height: 27.v),
                                        Container(
                                          width: 414.h,
                                          margin: EdgeInsets.only(left: 1.h),
                                          padding: EdgeInsets.symmetric(
                                            horizontal: 19.h,
                                            vertical: 11.v,
                                          ),
                                          decoration: AppDecoration
                                              .outlinePrimary2
                                              .copyWith(
                                            borderRadius: BorderRadiusStyle
                                                .roundedBorder20,
                                          ),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              SizedBox(height: 4.v),
                                              Text(
                                                "msg_geotagging_image".tr,
                                                style: theme
                                                    .textTheme.displaySmall,
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(height: 42.v),
                                        CustomElevatedButton(
                                          text: "lbl_submit".tr,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildComplaintsRow(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 65.h),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgBack,
            height: 64.adaptSize,
            width: 64.adaptSize,
            margin: EdgeInsets.only(bottom: 50.v),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 23.h,
              top: 23.v,
            ),
            child: Text(
              "lbl_complaints2".tr,
              style: CustomTextStyles.akayaKanadakaOnPrimaryContainer,
            ),
          ),
        ],
      ),
    );
  }
}
