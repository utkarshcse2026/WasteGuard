import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_ten_screen/models/desktop_ten_model.dart';
part 'desktop_ten_event.dart';
part 'desktop_ten_state.dart';

/// A bloc that manages the state of a DesktopTen according to the event that is dispatched to it.
class DesktopTenBloc extends Bloc<DesktopTenEvent, DesktopTenState> {
  DesktopTenBloc(DesktopTenState initialState) : super(initialState) {
    on<DesktopTenInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopTenInitialEvent event,
    Emitter<DesktopTenState> emit,
  ) async {}
}
