// ignore_for_file: must_be_immutable

part of 'desktop_ten_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///DesktopTen widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class DesktopTenEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the DesktopTen widget is first created.
class DesktopTenInitialEvent extends DesktopTenEvent {
  @override
  List<Object?> get props => [];
}
