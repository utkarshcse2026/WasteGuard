// ignore_for_file: must_be_immutable

part of 'desktop_ten_bloc.dart';

/// Represents the state of DesktopTen in the application.
class DesktopTenState extends Equatable {
  DesktopTenState({this.desktopTenModelObj});

  DesktopTenModel? desktopTenModelObj;

  @override
  List<Object?> get props => [
        desktopTenModelObj,
      ];

  DesktopTenState copyWith({DesktopTenModel? desktopTenModelObj}) {
    return DesktopTenState(
      desktopTenModelObj: desktopTenModelObj ?? this.desktopTenModelObj,
    );
  }
}
