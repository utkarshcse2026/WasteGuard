import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/widgets/custom_outlined_button.dart';
import 'bloc/desktop_two_bloc.dart';
import 'models/desktop_two_model.dart';

class DesktopTwoScreen extends StatelessWidget {
  const DesktopTwoScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopTwoBloc>(
      create: (context) => DesktopTwoBloc(DesktopTwoState(
        desktopTwoModelObj: DesktopTwoModel(),
      ))
        ..add(DesktopTwoInitialEvent()),
      child: DesktopTwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DesktopTwoBloc, DesktopTwoState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            extendBody: true,
            extendBodyBehindAppBar: true,
            body: Container(
              width: SizeUtils.width,
              height: SizeUtils.height,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment(0.5, 0),
                  end: Alignment(0.5, 1),
                  colors: [
                    appTheme.greenA200,
                    appTheme.greenA200.withOpacity(0.67),
                    appTheme.greenA200.withOpacity(0),
                  ],
                ),
              ),
              child: _buildUSERNAME(context),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildUSERNAME(BuildContext context) {
    return SizedBox(
      height: 106.v,
      width: 594.h,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgWhatIsAWaste,
            height: 1069.v,
            width: 594.h,
            alignment: Alignment.center,
          ),
          Align(
            alignment: Alignment.center,
            child: SingleChildScrollView(
              child: Container(
                height: 1058.v,
                width: 594.h,
                margin: EdgeInsets.only(bottom: 2.v),
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    Align(
                      alignment: Alignment.topCenter,
                      child: Padding(
                        padding: EdgeInsets.only(left: 21.h),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgBack,
                                  height: 64.adaptSize,
                                  width: 64.adaptSize,
                                  margin: EdgeInsets.only(
                                    top: 28.v,
                                    bottom: 246.v,
                                  ),
                                ),
                                Container(
                                  height: 338.v,
                                  width: 472.h,
                                  margin: EdgeInsets.only(left: 37.h),
                                  child: Stack(
                                    alignment: Alignment.bottomRight,
                                    children: [
                                      Align(
                                        alignment: Alignment.bottomLeft,
                                        child: Container(
                                          decoration:
                                              AppDecoration.outlinePrimary,
                                          child: Text(
                                            "lbl_welcome_back".tr,
                                            style:
                                                theme.textTheme.displayMedium,
                                          ),
                                        ),
                                      ),
                                      CustomImageView(
                                        imagePath:
                                            ImageConstant.imgCurvedGreenLeaf,
                                        height: 188.v,
                                        width: 274.h,
                                        alignment: Alignment.bottomRight,
                                        margin: EdgeInsets.only(bottom: 28.v),
                                      ),
                                      CustomImageView(
                                        imagePath:
                                            ImageConstant.imgSmilingManWith,
                                        height: 328.v,
                                        width: 255.h,
                                        alignment: Alignment.topLeft,
                                        margin: EdgeInsets.only(left: 47.h),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 115.h),
                              child: Text(
                                "msg_login_to_your_account".tr,
                                style: CustomTextStyles.displaySmallGray300,
                              ),
                            ),
                            SizedBox(height: 65.v),
                            CustomOutlinedButton(
                              text: "lbl_user_name".tr,
                              margin: EdgeInsets.only(
                                left: 27.h,
                                right: 48.h,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: SizedBox(
                        height: 504.v,
                        width: 594.h,
                        child: Stack(
                          alignment: Alignment.topCenter,
                          children: [
                            CustomImageView(
                              imagePath: ImageConstant.imgGreenInfographics,
                              height: 504.v,
                              width: 594.h,
                              alignment: Alignment.center,
                            ),
                            Align(
                              alignment: Alignment.topCenter,
                              child: Padding(
                                padding: EdgeInsets.only(
                                  left: 48.h,
                                  top: 2.v,
                                  right: 48.h,
                                ),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SizedBox(
                                      height: 136.v,
                                      width: 498.h,
                                      child: Stack(
                                        alignment: Alignment.bottomRight,
                                        children: [
                                          Align(
                                            alignment: Alignment.topCenter,
                                            child: Container(
                                              margin:
                                                  EdgeInsets.only(bottom: 63.v),
                                              padding: EdgeInsets.all(5.h),
                                              decoration: AppDecoration
                                                  .outlineWhiteA
                                                  .copyWith(
                                                borderRadius: BorderRadiusStyle
                                                    .roundedBorder15,
                                              ),
                                              child: Row(
                                                children: [
                                                  CustomImageView(
                                                    imagePath:
                                                        ImageConstant.imgSecure,
                                                    height: 60.v,
                                                    width: 64.h,
                                                    margin: EdgeInsets.only(
                                                        top: 1.v),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                      left: 17.h,
                                                      top: 7.v,
                                                      bottom: 8.v,
                                                    ),
                                                    child: Text(
                                                      "lbl_password".tr,
                                                      style: CustomTextStyles
                                                          .displaySmall37,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Align(
                                            alignment: Alignment.bottomRight,
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                left: 40.h,
                                                top: 83.v,
                                                bottom: 17.v,
                                              ),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "lbl_remember_me".tr,
                                                    style: CustomTextStyles
                                                        .headlineLargeGray400,
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                      top: 9.v,
                                                      bottom: 12.v,
                                                    ),
                                                    decoration: AppDecoration
                                                        .outlinePrimary,
                                                    child: Text(
                                                      "msg_forgot_password".tr,
                                                      style: CustomTextStyles
                                                          .headlineLargeWhiteA700,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          CustomImageView(
                                            imagePath:
                                                ImageConstant.imgCheckmark,
                                            height: 67.v,
                                            width: 32.h,
                                            alignment: Alignment.bottomLeft,
                                            margin: EdgeInsets.only(left: 6.h),
                                          ),
                                        ],
                                      ),
                                    ),
                                    SizedBox(height: 67.v),
                                    CustomOutlinedButton(
                                      text: "lbl_login".tr,
                                      buttonStyle:
                                          CustomButtonStyles.outlineGreen,
                                      buttonTextStyle:
                                          CustomTextStyles.displayMedium45,
                                    ),
                                    SizedBox(height: 11.v),
                                    RichText(
                                      text: TextSpan(
                                        children: [
                                          TextSpan(
                                            text: "msg_don_t_have_account2".tr,
                                            style: CustomTextStyles
                                                .displaySmallffc8c4c4,
                                          ),
                                          TextSpan(
                                            text: "lbl_sign_up".tr,
                                            style: CustomTextStyles
                                                .displaySmallff06197b,
                                          ),
                                        ],
                                      ),
                                      textAlign: TextAlign.left,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
