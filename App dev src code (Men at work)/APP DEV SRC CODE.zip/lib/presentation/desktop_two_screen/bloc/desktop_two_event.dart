// ignore_for_file: must_be_immutable

part of 'desktop_two_bloc.dart';

/// Abstract class for all events that can be dispatched from the
///DesktopTwo widget.
///
/// Events must be immutable and implement the [Equatable] interface.
@immutable
abstract class DesktopTwoEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the DesktopTwo widget is first created.
class DesktopTwoInitialEvent extends DesktopTwoEvent {
  @override
  List<Object?> get props => [];
}
