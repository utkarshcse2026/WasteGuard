// ignore_for_file: must_be_immutable

part of 'desktop_two_bloc.dart';

/// Represents the state of DesktopTwo in the application.
class DesktopTwoState extends Equatable {
  DesktopTwoState({this.desktopTwoModelObj});

  DesktopTwoModel? desktopTwoModelObj;

  @override
  List<Object?> get props => [
        desktopTwoModelObj,
      ];

  DesktopTwoState copyWith({DesktopTwoModel? desktopTwoModelObj}) {
    return DesktopTwoState(
      desktopTwoModelObj: desktopTwoModelObj ?? this.desktopTwoModelObj,
    );
  }
}
