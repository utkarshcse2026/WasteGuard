import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_two_screen/models/desktop_two_model.dart';
part 'desktop_two_event.dart';
part 'desktop_two_state.dart';

/// A bloc that manages the state of a DesktopTwo according to the event that is dispatched to it.
class DesktopTwoBloc extends Bloc<DesktopTwoEvent, DesktopTwoState> {
  DesktopTwoBloc(DesktopTwoState initialState) : super(initialState) {
    on<DesktopTwoInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopTwoInitialEvent event,
    Emitter<DesktopTwoState> emit,
  ) async {}
}
