// ignore_for_file: must_be_immutable

part of 'desktop_six_bloc.dart';

/// Represents the state of DesktopSix in the application.
class DesktopSixState extends Equatable {
  DesktopSixState({
    this.otpController,
    this.desktopSixModelObj,
  });

  TextEditingController? otpController;

  DesktopSixModel? desktopSixModelObj;

  @override
  List<Object?> get props => [
        otpController,
        desktopSixModelObj,
      ];

  DesktopSixState copyWith({
    TextEditingController? otpController,
    DesktopSixModel? desktopSixModelObj,
  }) {
    return DesktopSixState(
      otpController: otpController ?? this.otpController,
      desktopSixModelObj: desktopSixModelObj ?? this.desktopSixModelObj,
    );
  }
}
