import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/widgets/custom_elevated_button.dart';
import 'package:waste_guard/widgets/custom_pin_code_text_field.dart';
import 'bloc/desktop_six_bloc.dart';
import 'models/desktop_six_model.dart';

class DesktopSixScreen extends StatelessWidget {
  const DesktopSixScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopSixBloc>(
      create: (context) => DesktopSixBloc(DesktopSixState(
        desktopSixModelObj: DesktopSixModel(),
      ))
        ..add(DesktopSixInitialEvent()),
      child: DesktopSixScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: 594.h,
          child: Column(
            children: [
              SizedBox(height: 37.v),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.imgBack,
                        height: 64.adaptSize,
                        width: 64.adaptSize,
                        margin: EdgeInsets.only(left: 21.h),
                      ),
                      SizedBox(height: 96.v),
                      SizedBox(
                        height: 870.v,
                        width: 594.h,
                        child: Stack(
                          alignment: Alignment.topCenter,
                          children: [
                            CustomImageView(
                              imagePath:
                                  ImageConstant.imgGreenInfographics459x594,
                              height: 459.v,
                              width: 594.h,
                              alignment: Alignment.bottomCenter,
                            ),
                            _buildOtpViewContent(context),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildOtpViewContent(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 41.h),
        padding: EdgeInsets.all(16.h),
        decoration: AppDecoration.fillGreen.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder50,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: EdgeInsets.only(right: 138.h),
                child: Text(
                  "lbl_invalid".tr,
                  style: CustomTextStyles.displayMediumRedA700,
                ),
              ),
            ),
            SizedBox(height: 24.v),
            Align(
              alignment: Alignment.center,
              child: Text(
                "msg_please_enter_the".tr,
                style: CustomTextStyles.headlineLargeRedA70001,
              ),
            ),
            SizedBox(height: 33.v),
            Padding(
              padding: EdgeInsets.only(left: 54.h),
              child: Text(
                "msg_enter_the_code_here".tr,
                style: theme.textTheme.displaySmall,
              ),
            ),
            SizedBox(height: 25.v),
            Padding(
              padding: EdgeInsets.only(right: 19.h),
              child: BlocSelector<DesktopSixBloc, DesktopSixState,
                  TextEditingController?>(
                selector: (state) => state.otpController,
                builder: (context, otpController) {
                  return CustomPinCodeTextField(
                    context: context,
                    controller: otpController,
                    onChanged: (value) {
                      otpController?.text = value;
                    },
                  );
                },
              ),
            ),
            SizedBox(height: 36.v),
            CustomElevatedButton(
              height: 82.v,
              text: "lbl_re_send_code".tr,
              margin: EdgeInsets.only(
                left: 27.h,
                right: 34.h,
              ),
              buttonStyle: CustomButtonStyles.outlinePrimary,
              alignment: Alignment.center,
            ),
            SizedBox(height: 56.v),
          ],
        ),
      ),
    );
  }
}
