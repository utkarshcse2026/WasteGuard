import 'package:flutter/material.dart';
import 'package:waste_guard/core/app_export.dart';
import 'package:waste_guard/widgets/custom_elevated_button.dart';
import 'bloc/desktop_four_bloc.dart';
import 'models/desktop_four_model.dart';

class DesktopFourScreen extends StatelessWidget {
  const DesktopFourScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<DesktopFourBloc>(
      create: (context) => DesktopFourBloc(DesktopFourState(
        desktopFourModelObj: DesktopFourModel(),
      ))
        ..add(DesktopFourInitialEvent()),
      child: DesktopFourScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<DesktopFourBloc, DesktopFourState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: SizedBox(
              width: 594.h,
              child: Column(
                children: [
                  SizedBox(height: 37.v),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 21.h),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: 64.adaptSize,
                                  width: 64.adaptSize,
                                  margin: EdgeInsets.only(bottom: 149.v),
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      CustomImageView(
                                        imagePath: ImageConstant.imgBack,
                                        height: 64.adaptSize,
                                        width: 64.adaptSize,
                                        alignment: Alignment.center,
                                      ),
                                      CustomImageView(
                                        imagePath: ImageConstant.imgBack,
                                        height: 64.adaptSize,
                                        width: 64.adaptSize,
                                        alignment: Alignment.center,
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: 174.v,
                                  width: 242.h,
                                  margin: EdgeInsets.only(
                                    left: 91.h,
                                    top: 39.v,
                                  ),
                                  child: Stack(
                                    alignment: Alignment.bottomRight,
                                    children: [
                                      CustomImageView(
                                        imagePath: ImageConstant.imgMaleUser,
                                        height: 174.v,
                                        width: 242.h,
                                        alignment: Alignment.center,
                                      ),
                                      CustomImageView(
                                        imagePath: ImageConstant.imgUnsplash,
                                        height: 64.adaptSize,
                                        width: 64.adaptSize,
                                        alignment: Alignment.bottomRight,
                                        margin: EdgeInsets.only(
                                          right: 33.h,
                                          bottom: 1.v,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 28.v),
                          SizedBox(
                            height: 789.v,
                            width: 594.h,
                            child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                _buildCreateAccountStack(context),
                                Align(
                                  alignment: Alignment.topCenter,
                                  child: Container(
                                    margin:
                                        EdgeInsets.symmetric(horizontal: 41.h),
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 12.h,
                                      vertical: 34.v,
                                    ),
                                    decoration:
                                        AppDecoration.fillGreen.copyWith(
                                      borderRadius:
                                          BorderRadiusStyle.roundedBorder50,
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        _buildFullNameStack(context),
                                        SizedBox(height: 18.v),
                                        _buildPhoneNoColumn(context),
                                        SizedBox(height: 21.v),
                                        _buildAddressColumn(context),
                                        SizedBox(height: 21.v),
                                        _buildAreaPincodeColumn(context),
                                        SizedBox(height: 20.v),
                                        CustomElevatedButton(
                                          height: 85.v,
                                          text: "lbl_about_youself".tr,
                                          margin: EdgeInsets.only(right: 7.h),
                                          buttonStyle: CustomButtonStyles
                                              .outlinePrimaryTL10,
                                          buttonTextStyle: CustomTextStyles
                                              .displayMediumOnPrimaryContainer_1,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildCreateAccountStack(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: SizedBox(
        height: 459.v,
        width: 594.h,
        child: Stack(
          alignment: Alignment.bottomCenter,
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgGreenInfographics459x594,
              height: 459.v,
              width: 594.h,
              alignment: Alignment.center,
            ),
            CustomElevatedButton(
              height: 82.v,
              width: 419.h,
              text: "lbl_create_account".tr,
              margin: EdgeInsets.only(bottom: 112.v),
              buttonStyle: CustomButtonStyles.outlinePrimary,
              alignment: Alignment.bottomCenter,
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFullNameStack(BuildContext context) {
    return SizedBox(
      height: 87.v,
      width: 481.h,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.bottomLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 29.h),
              child: Text(
                "lbl_full".tr,
                style: theme.textTheme.bodySmall,
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: 21.h,
                vertical: 11.v,
              ),
              decoration: AppDecoration.outlinePrimary1.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder10,
              ),
              child: Text(
                "lbl_full_name".tr,
                style: CustomTextStyles.displayMediumOnPrimaryContainer_1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildPhoneNoColumn(BuildContext context) {
    return Container(
      width: 481.h,
      margin: EdgeInsets.only(right: 7.h),
      padding: EdgeInsets.symmetric(
        horizontal: 20.h,
        vertical: 10.v,
      ),
      decoration: AppDecoration.outlinePrimary1.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder10,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 4.v),
          Text(
            "lbl_phone_no".tr,
            style: CustomTextStyles.displayMediumOnPrimaryContainer_1,
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildAddressColumn(BuildContext context) {
    return Container(
      width: 481.h,
      margin: EdgeInsets.only(right: 7.h),
      padding: EdgeInsets.symmetric(
        horizontal: 19.h,
        vertical: 10.v,
      ),
      decoration: AppDecoration.outlinePrimary1.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder10,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 4.v),
          Text(
            "lbl_address".tr,
            style: CustomTextStyles.displayMediumOnPrimaryContainer_1,
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildAreaPincodeColumn(BuildContext context) {
    return Container(
      width: 481.h,
      margin: EdgeInsets.only(right: 7.h),
      padding: EdgeInsets.symmetric(
        horizontal: 21.h,
        vertical: 7.v,
      ),
      decoration: AppDecoration.outlinePrimary1.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder10,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 10.v),
          Text(
            "lbl_area_pincode".tr,
            style: CustomTextStyles.displayMediumOnPrimaryContainer_1,
          ),
        ],
      ),
    );
  }
}
