// ignore_for_file: must_be_immutable

part of 'desktop_four_bloc.dart';

/// Represents the state of DesktopFour in the application.
class DesktopFourState extends Equatable {
  DesktopFourState({this.desktopFourModelObj});

  DesktopFourModel? desktopFourModelObj;

  @override
  List<Object?> get props => [
        desktopFourModelObj,
      ];

  DesktopFourState copyWith({DesktopFourModel? desktopFourModelObj}) {
    return DesktopFourState(
      desktopFourModelObj: desktopFourModelObj ?? this.desktopFourModelObj,
    );
  }
}
