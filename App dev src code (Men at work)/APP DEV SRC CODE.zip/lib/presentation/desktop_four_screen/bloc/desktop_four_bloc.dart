import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:waste_guard/presentation/desktop_four_screen/models/desktop_four_model.dart';
part 'desktop_four_event.dart';
part 'desktop_four_state.dart';

/// A bloc that manages the state of a DesktopFour according to the event that is dispatched to it.
class DesktopFourBloc extends Bloc<DesktopFourEvent, DesktopFourState> {
  DesktopFourBloc(DesktopFourState initialState) : super(initialState) {
    on<DesktopFourInitialEvent>(_onInitialize);
  }

  _onInitialize(
    DesktopFourInitialEvent event,
    Emitter<DesktopFourState> emit,
  ) async {}
}
